'use client';

import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Briefcase, FileText, GraduationCap, Users } from 'lucide-react';

const stats = [
  { icon: Briefcase, value: 25, suffix: '+', label: 'سنة خبرة مهنية' },
  { icon: FileText, value: 25, suffix: '+', label: 'بحث ومنشور أكاديمي' },
  { icon: GraduationCap, value: 10, suffix: '+', label: 'مقرر أكاديمي' },
  { icon: Users, value: 50, suffix: '+', label: 'استشارة مهنية' },
];

function AnimatedCounter({ value, suffix }: { value: number; suffix: string }) {
  const [count, setCount] = useState(0);
  const [hasAnimated, setHasAnimated] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasAnimated) {
          setHasAnimated(true);
          const duration = 2000;
          const steps = 60;
          const stepValue = value / steps;
          let current = 0;
          const interval = setInterval(() => {
            current += stepValue;
            if (current >= value) {
              setCount(value);
              clearInterval(interval);
            } else {
              setCount(Math.floor(current));
            }
          }, duration / steps);
        }
      },
      { threshold: 0.3 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [value, hasAnimated]);

  return (
    <div ref={ref} className="text-3xl md:text-4xl lg:text-5xl font-bold text-white tabular-nums">
      {count}{suffix}
    </div>
  );
}

export default function StatsSection() {
  return (
    <section className="relative py-16 md:py-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-r from-[#0F2B4C] via-[#162D50] to-[#0F2B4C]" />
      <div className="absolute inset-0 opacity-[0.04]" style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M20 20h20v20H20z'/%3E%3C/g%3E%3C/svg%3E")`,
      }} />
      
      {/* Decorative circles */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-[var(--gold)]/5 rounded-full blur-[80px]" />
      <div className="absolute bottom-0 right-0 w-64 h-64 bg-[var(--accent-blue)]/8 rounded-full blur-[80px]" />

      <div className="relative container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-6 lg:gap-12">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.15 }}
              className="text-center"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 md:w-18 md:h-18 rounded-2xl bg-white/10 mb-4 shadow-lg shadow-black/10 border border-white/10">
                <stat.icon className="w-7 h-7 md:w-8 md:h-8 text-[var(--gold)]" />
              </div>
              <AnimatedCounter value={stat.value} suffix={stat.suffix} />
              <div className="text-white/60 text-sm md:text-base mt-2 font-medium">
                {stat.label}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
