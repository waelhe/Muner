'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, GraduationCap } from 'lucide-react';
import ThemeToggle from '@/components/ThemeToggle';
import { Button } from '@/components/ui/button';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

interface Profile {
  id: string;
  name: string;
  title: string;
}

const navItems = [
  { id: 'home', label: 'الرئيسية' },
  { id: 'about', label: 'عني' },
  { id: 'research', label: 'الأبحاث' },
  { id: 'videos', label: 'المرئيات' },
  { id: 'courses', label: 'المقررات' },
  { id: 'consultations', label: 'الاستشارات' },
  { id: 'contact', label: 'تواصل معي' },
];

export default function Navbar({ currentPage, onNavigate }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    fetch('/api/profile')
      .then(res => res.json())
      .then(data => setProfile(data))
      .catch(() => {});
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavigate = (page: string) => {
    onNavigate(page);
    setIsOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <nav className={`sticky top-0 z-50 transition-all duration-300 ${
      scrolled 
        ? 'navbar-glass shadow-lg shadow-[#0F2B4C]/5 dark:shadow-black/20' 
        : 'bg-white/95 dark:bg-[#0A1220]/95 backdrop-blur-sm border-b border-border/50'
    }`}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <button
            onClick={() => handleNavigate('home')}
            className="flex items-center gap-3 hover:opacity-80 transition-opacity group"
          >
            <div className="relative w-11 h-11 md:w-12 md:h-12 rounded-xl bg-gradient-to-br from-[#0F2B4C] to-[#1A3A5C] flex items-center justify-center shadow-md shadow-[#0F2B4C]/20 dark:shadow-black/30 group-hover:shadow-lg group-hover:shadow-[#0F2B4C]/30 dark:group-hover:shadow-black/40 transition-shadow">
              <GraduationCap className="w-5 h-5 md:w-6 md:h-6 text-[var(--gold)]" />
              <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-[var(--gold)] rounded-full border-2 border-white dark:border-[#111B2B]" />
            </div>
            <div className="hidden sm:block">
              <div className="font-bold text-[#0F2B4C] dark:text-[#E8ECF1] text-sm md:text-base leading-tight group-hover:text-[var(--gold)] transition-colors">
                {profile?.name || 'أستاذ دكتور منير عباس'}
              </div>
              <div className="text-[11px] text-muted-foreground font-medium">إدارة الموارد البشرية والقيادة</div>
            </div>
          </button>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavigate(item.id)}
                className={`relative px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
                  currentPage === item.id
                    ? 'text-[#0F2B4C] dark:text-[#E8ECF1] bg-[#0F2B4C]/8 dark:bg-white/10'
                    : 'text-foreground/70 hover:text-[#0F2B4C] dark:hover:text-[#E8ECF1] hover:bg-[#0F2B4C]/5 dark:hover:bg-white/5'
                }`}
              >
                {item.label}
                {currentPage === item.id && (
                  <motion.div
                    layoutId="navbar-indicator"
                    className="absolute bottom-0 right-2 left-2 h-0.5 bg-[var(--gold)] rounded-full"
                    transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                  />
                )}
              </button>
            ))}
          </div>

          {/* Theme Toggle & Mobile Menu Button */}
          <div className="flex items-center gap-1">
            <ThemeToggle />
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden hover:bg-[#0F2B4C]/5 dark:hover:bg-white/10"
              onClick={() => setIsOpen(!isOpen)}
              aria-label={isOpen ? 'إغلاق القائمة' : 'فتح القائمة'}
            >
              {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="lg:hidden bg-white/98 dark:bg-[#0A1220]/98 backdrop-blur-xl border-b border-border/50 overflow-hidden"
          >
            <div className="container mx-auto px-4 py-4 space-y-1">
              {navItems.map((item, index) => (
                <motion.button
                  key={item.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => handleNavigate(item.id)}
                  className={`block w-full text-right px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                    currentPage === item.id
                      ? 'bg-[#0F2B4C] dark:bg-[#4A8BC2] text-white shadow-md shadow-[#0F2B4C]/20 dark:shadow-black/30'
                      : 'text-foreground/70 hover:bg-[#0F2B4C]/5 dark:hover:bg-white/5 hover:text-[#0F2B4C] dark:hover:text-[#E8ECF1]'
                  }`}
                >
                  {item.label}
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
