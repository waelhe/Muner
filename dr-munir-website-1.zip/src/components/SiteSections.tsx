'use client';

import { motion } from 'framer-motion';
import {
  User,
  BookOpen,
  PlayCircle,
  GraduationCap,
  MessageSquareText,
  Phone,
} from 'lucide-react';

interface SiteSectionsProps {
  onNavigate: (page: string) => void;
}

const sections = [
  {
    id: 'about',
    label: 'عني',
    description: 'تعرف على المسيرة الأكاديمية والمهنية',
    icon: User,
    gradient: 'from-[#0F2B4C] to-[#1A3A5C]',
    iconBg: 'bg-[#0F2B4C]/10',
    iconColor: 'text-[#0F2B4C]',
    hoverBorder: 'hover:border-[#0F2B4C]/30',
  },
  {
    id: 'research',
    label: 'الأبحاث',
    description: 'الأبحاث والدراسات الأكاديمية المنشورة',
    icon: BookOpen,
    gradient: 'from-[var(--accent-blue)] to-[#3D7FC4]',
    iconBg: 'bg-[var(--accent-blue)]/10',
    iconColor: 'text-[var(--accent-blue)]',
    hoverBorder: 'hover:border-[var(--accent-blue)]/30',
  },
  {
    id: 'videos',
    label: 'المرئيات',
    description: 'فيديوهات تعليمية وإرشادية في الموارد البشرية',
    icon: PlayCircle,
    gradient: 'from-[var(--gold)] to-[#C9960E]',
    iconBg: 'bg-[var(--gold)]/10',
    iconColor: 'text-[var(--gold)]',
    hoverBorder: 'hover:border-[var(--gold)]/30',
  },
  {
    id: 'courses',
    label: 'المقررات',
    description: 'المقررات الأكاديمية والمواد التدريسية',
    icon: GraduationCap,
    gradient: 'from-[#1A5C3A] to-[#2A7C4A]',
    iconBg: 'bg-emerald-500/10',
    iconColor: 'text-emerald-600',
    hoverBorder: 'hover:border-emerald-500/30',
  },
  {
    id: 'consultations',
    label: 'الاستشارات',
    description: 'خدمات الاستشارات المهنية والتدريبية',
    icon: MessageSquareText,
    gradient: 'from-[#6B3FA0] to-[#8B5FC0]',
    iconBg: 'bg-violet-500/10',
    iconColor: 'text-violet-600',
    hoverBorder: 'hover:border-violet-500/30',
  },
  {
    id: 'contact',
    label: 'تواصل معي',
    description: 'تواصل مباشرة للاستفسار والحجز',
    icon: Phone,
    gradient: 'from-[#C0392B] to-[#E74C3C]',
    iconBg: 'bg-red-500/10',
    iconColor: 'text-red-500',
    hoverBorder: 'hover:border-red-500/30',
  },
];

export default function SiteSections({ onNavigate }: SiteSectionsProps) {
  return (
    <section className="py-14 md:py-20 bg-[var(--background)]">
      <div className="container mx-auto px-4">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-10 md:mb-14"
        >
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-[#0F2B4C] dark:text-[#E8ECF1] mb-3">
            أقسام الموقع
          </h2>
          <p className="text-muted-foreground text-base md:text-lg">
            استكشف محتوى الموقع واعرف المزيد
          </p>
          <div className="mt-5 flex items-center gap-2 justify-center">
            <div className="h-[2px] w-8 bg-[var(--gold)] rounded-full" />
            <div className="w-2 h-2 rounded-full bg-[var(--gold)]" />
            <div className="h-[2px] w-16 bg-gradient-to-r from-[var(--gold)] to-[var(--accent-blue)] rounded-full" />
            <div className="w-2 h-2 rounded-full bg-[var(--accent-blue)]" />
            <div className="h-[2px] w-8 bg-[var(--accent-blue)] rounded-full" />
          </div>
        </motion.div>

        {/* Sections Grid */}
        <div className="grid grid-cols-3 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 md:gap-5">
          {sections.map((section, index) => (
            <motion.button
              key={section.id}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.08 }}
              onClick={() => onNavigate(section.id)}
              className={`group relative bg-white dark:bg-[#111B2B] rounded-2xl p-3 sm:p-5 md:p-6 border border-[var(--border)] dark:border-[#1E2D42] ${section.hoverBorder} shadow-sm hover:shadow-xl hover:shadow-[#0F2B4C]/8 dark:hover:shadow-black/20 transition-all duration-400 cursor-pointer card-hover-academic text-center touch-target`}
            >
              {/* Icon */}
              <div className={`inline-flex items-center justify-center w-11 h-11 sm:w-14 sm:h-14 md:w-16 md:h-16 rounded-xl sm:rounded-2xl ${section.iconBg} mb-3 sm:mb-4 group-hover:scale-110 transition-transform duration-300 mx-auto`}>
                <section.icon className={`w-5 h-5 sm:w-7 sm:h-7 md:w-8 md:h-8 ${section.iconColor} transition-colors duration-300`} />
              </div>

              {/* Label */}
              <h3 className="font-bold text-xs sm:text-sm md:text-base text-[#0F2B4C] dark:text-[#E8ECF1] group-hover:text-[var(--gold)] transition-colors duration-300 mb-1 sm:mb-1.5">
                {section.label}
              </h3>

              {/* Description */}
              <p className="text-muted-foreground text-[10px] sm:text-[11px] md:text-xs leading-relaxed line-clamp-2 sm:line-clamp-2">
                {section.description}
              </p>

              {/* Arrow indicator */}
              <div className="mt-3 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-1 group-hover:translate-y-0">
                <svg className="w-4 h-4 text-[var(--gold)] mx-auto rotate-180" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <polyline points="15 18 9 12 15 6" />
                </svg>
              </div>
            </motion.button>
          ))}
        </div>
      </div>
    </section>
  );
}
