'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Play, BookOpen, Users, Award } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Image from 'next/image';

interface Profile {
  id: string;
  name: string;
  title: string;
  bio: string;
}

interface HeroSectionProps {
  onNavigate: (page: string) => void;
}

export default function HeroSection({ onNavigate }: HeroSectionProps) {
  const [profile, setProfile] = useState<Profile | null>(null);

  useEffect(() => {
    fetch('/api/profile')
      .then(res => res.json())
      .then(data => setProfile(data))
      .catch(() => {});
  }, []);

  return (
    <section className="relative min-h-[85vh] md:min-h-[90vh] overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-bl from-[#0F2B4C] via-[#162D50] to-[#1A3A5C] animate-gradient" />
      
      {/* Decorative elements */}
      <div className="absolute inset-0 hero-pattern" />
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-[var(--gold)]/5 rounded-full blur-[120px] -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-[var(--accent-blue)]/8 rounded-full blur-[100px] translate-x-1/3 translate-y-1/3" />
      
      {/* Geometric pattern overlay */}
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v6h-6v-6h6zm0-30v6h-6V4h6zm0 10v6h-6v-6h6zm0 10v6h-6v-6h6zm-10 0v6h-6v-6h6zm-10 0v6h-6v-6h6zm30 0v6h-6v-6h6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
      }} />

      <div className="relative container mx-auto px-4 py-12 md:py-16 lg:py-0 min-h-[85vh] md:min-h-[90vh] flex items-start lg:items-center">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center w-full">
          {/* Text Content */}
          <div className="order-2 lg:order-1">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
            >
              <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md rounded-full px-4 py-2 sm:px-5 sm:py-2.5 mb-6 border border-white/15">
                <span className="w-2 h-2 rounded-full bg-[var(--gold)] animate-pulse-gold" />
                <span className="text-[var(--gold)] text-xs sm:text-sm font-semibold drop-shadow-[0_1px_2px_rgba(0,0,0,0.3)]">أستاذ دكتور في إدارة الموارد البشرية</span>
              </div>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.15 }}
              className="text-responsive-hero font-bold text-white mb-5 leading-tight drop-shadow-[0_2px_8px_rgba(0,0,0,0.4)]"
            >
              {profile?.name || 'أستاذ دكتور منير عباس'}
            </motion.h1>

            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.3 }}
              className="text-base sm:text-lg md:text-xl lg:text-2xl font-semibold mb-5 leading-relaxed text-[#D4A843] drop-shadow-[0_1px_4px_rgba(0,0,0,0.3)] text-wrap"
            >
              {profile?.title || 'رئيس مجلس أمناء مؤسسة إدارة الموارد البشرية في سورية'}
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.45 }}
              className="text-white/85 text-xs sm:text-sm md:text-base leading-[1.8] mb-8 max-w-xl drop-shadow-[0_1px_3px_rgba(0,0,0,0.3)] text-wrap"
            >
              {profile?.bio || 'أكاديمي واستشاري متخصص في إدارة الموارد البشرية، بخبرة تزيد عن 25 عاماً في التدريس والاستشارات والتدريب.'}
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.6 }}
              className="flex flex-wrap gap-3 mb-8"
            >
              <Button
                onClick={() => onNavigate('contact')}
                size="lg"
                className="btn-academic bg-[var(--gold)] hover:bg-[#C9960E] text-[#0F2B4C] font-bold gap-2 rounded-xl px-5 sm:px-8 h-11 sm:h-12 text-sm sm:text-base shadow-lg shadow-[var(--gold)]/20 touch-target"
              >
                تواصل معي
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <Button
                onClick={() => onNavigate('research')}
                variant="outline"
                size="lg"
                className="btn-academic border-white/25 text-white hover:bg-white/10 gap-2 rounded-xl px-5 sm:px-8 h-11 sm:h-12 text-sm sm:text-base bg-white/5 touch-target"
              >
                أبحاثي
                <Play className="w-4 h-4" />
              </Button>
            </motion.div>

            {/* Quick Stats */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.75 }}
              className="flex items-center gap-3 sm:gap-6 md:gap-8 flex-wrap"
            >
              {[
                { icon: Award, value: '25+', label: 'سنة خبرة' },
                { icon: BookOpen, value: '25+', label: 'بحث ومنشور' },
                { icon: Users, value: '50+', label: 'استشارة' },
              ].map((stat, i) => (
                <div key={i} className="flex items-center gap-2">
                  <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg bg-white/15 backdrop-blur-sm flex items-center justify-center border border-white/10">
                    <stat.icon className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[var(--gold)]" />
                  </div>
                  <div>
                    <div className="text-white font-bold text-sm sm:text-lg leading-none drop-shadow-[0_1px_3px_rgba(0,0,0,0.3)]">{stat.value}</div>
                    <div className="text-white/70 text-[10px] sm:text-xs mt-0.5">{stat.label}</div>
                  </div>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Image Section */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="order-1 lg:order-2 flex justify-center lg:justify-end"
          >
            <div className="relative">
              {/* Decorative elements */}
              <div className="absolute -inset-4 rounded-3xl border-2 border-[var(--gold)]/20 animate-float" />
              <div className="absolute -inset-8 rounded-3xl border border-white/5" />

              {/* Main image container - portrait ratio 3:4 matching image 720x960 */}
              <div className="relative w-[220px] h-[294px] sm:w-[280px] sm:h-[374px] md:w-[340px] md:h-[454px] lg:w-[380px] lg:h-[507px] rounded-2xl overflow-hidden shadow-2xl shadow-black/30 bg-gradient-to-b from-[#1a3d5c] to-[#0a1f3a]">
                <Image
                  src="/dr-munir-about.png"
                  alt="أستاذ دكتور منير عباس"
                  width={720}
                  height={960}
                  style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'top center' }}
                  priority
                />
                {/* Bottom gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0F2B4C]/60 via-transparent to-transparent z-10 pointer-events-none" />
                {/* Gold accent line at bottom */}
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-[var(--gold)] to-[var(--accent-blue)] z-20" />
              </div>

              {/* Floating badge - hidden on very small screens to avoid overlap */}
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.8 }}
                className="hidden sm:block absolute -left-4 md:-left-8 bottom-16 glass-dark rounded-xl px-4 py-3 shadow-xl"
              >
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-[var(--gold)]/20 flex items-center justify-center">
                    <Award className="w-4 h-4 text-[var(--gold)]" />
                  </div>
                  <div>
                    <div className="text-white text-xs font-bold">IHRM Syria</div>
                    <div className="text-white/70 text-[10px]">رئيس مجلس الأمناء</div>
                  </div>
                </div>
              </motion.div>

              {/* Floating badge top - hidden on very small screens to avoid overlap */}
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 1 }}
                className="hidden sm:block absolute -right-4 md:-right-6 top-12 glass-dark rounded-xl px-4 py-3 shadow-xl"
              >
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-[var(--accent-blue)]/20 flex items-center justify-center">
                    <BookOpen className="w-4 h-4 text-[var(--accent-blue)]" />
                  </div>
                  <div>
                    <div className="text-white text-xs font-bold">APCO</div>
                    <div className="text-white/70 text-[10px]">مستشار دولي</div>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Bottom wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 80" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full">
          <path d="M0 80L60 68C120 56 240 32 360 24C480 16 600 24 720 32C840 40 960 48 1080 44C1200 40 1320 24 1380 16L1440 8V80H0Z" fill="var(--background)" />
        </svg>
      </div>
    </section>
  );
}
