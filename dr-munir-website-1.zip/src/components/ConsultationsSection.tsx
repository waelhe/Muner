'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users, Building2, BarChart3, GraduationCap, MessageSquare, Quote, Star, RefreshCw, Scale } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import SectionTitle from '@/components/SectionTitle';

interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  order: number;
}

const iconMap: Record<string, React.ElementType> = {
  Users,
  Building2,
  BarChart3,
  GraduationCap,
  RefreshCw,
  Scale,
};

const testimonials = [
  {
    name: 'أحمد محمد',
    role: 'مدير الموارد البشرية - شركة تقنية',
    text: 'ساعدتنا استشارات الدكتور منير في بناء نظام تقييم أداء فعّال حسّن إنتاجية الفريق بنسبة 30%.',
  },
  {
    name: 'سارة العلي',
    role: 'مديرة التطوير - بنك سوري',
    text: 'البرنامج التدريبي المصمم خصيصاً لنا كان له أثر كبير في تطوير مهارات فريق القيادة لدينا.',
  },
  {
    name: 'خالد الحسن',
    role: 'مدير عام - مجموعة تجارية',
    text: 'استشارات الهيكل التنظيمي ساعدتنا في إعادة هيكلة الشركة بطريقة فعّالة ومنظمة.',
  },
];

interface ConsultationsSectionProps {
  onNavigate: (page: string) => void;
}

export default function ConsultationsSection({ onNavigate }: ConsultationsSectionProps) {
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/services')
      .then(res => res.json())
      .then(data => {
        setServices(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="py-16 md:py-24 bg-[var(--warm-cream)] dark:bg-[#0A1220]">
        <div className="container mx-auto px-4">
          <div className="animate-pulse">
            <div className="h-8 bg-secondary rounded w-48 mx-auto mb-6" />
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 mb-16">
              {[1, 2, 3, 4, 5, 6].map(i => (
                <div key={i} className="bg-card rounded-xl p-6 space-y-4">
                  <div className="w-14 h-14 rounded-xl bg-secondary" />
                  <div className="h-5 bg-secondary rounded w-3/4" />
                  <div className="h-4 bg-secondary rounded w-full" />
                  <div className="h-4 bg-secondary rounded w-5/6" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-16 md:py-24 bg-[var(--warm-cream)] dark:bg-[#0A1220]">
      <div className="container mx-auto px-4">
        <SectionTitle title="الاستشارات" subtitle="خدمات الاستشارات المهنية في مجال الموارد البشرية" />

        {/* Services Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 mb-16">
          {services.map((service, index) => {
            const IconComponent = iconMap[service.icon] || Users;
            return (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.08 }}
              >
                <Card className="h-full card-hover-academic border-0 shadow-md shadow-[#0F2B4C]/5 dark:shadow-black/20 bg-white dark:bg-[#111B2B] overflow-hidden">
                  <CardContent className="p-6">
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#0F2B4C] to-[#1A3A5C] flex items-center justify-center mb-5 shadow-md shadow-[#0F2B4C]/20 dark:shadow-black/30">
                      <IconComponent className="w-6 h-6 text-[var(--gold)]" />
                    </div>
                    <h3 className="font-bold text-lg text-[#0F2B4C] dark:text-[#E8ECF1] mb-3">{service.title}</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">{service.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Testimonials */}
        <div>
          <h3 className="text-xl md:text-2xl font-bold text-[#0F2B4C] dark:text-[#E8ECF1] text-center mb-10 flex items-center justify-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[var(--gold)]/10 flex items-center justify-center">
              <Quote className="w-5 h-5 text-[var(--gold)]" />
            </div>
            آراء العملاء
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
              >
                <Card className="h-full border-0 shadow-md shadow-[#0F2B4C]/5 dark:shadow-black/20 bg-white dark:bg-[#111B2B] overflow-hidden">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-1 mb-4">
                      {[1, 2, 3, 4, 5].map(star => (
                        <Star key={star} className="w-4 h-4 fill-[var(--gold)] text-[var(--gold)]" />
                      ))}
                    </div>
                    <p className="text-foreground/75 text-sm leading-[1.8] mb-5 italic">
                      &ldquo;{testimonial.text}&rdquo;
                    </p>
                    <div className="flex items-center gap-3 pt-4 border-t border-[#E0E6EF]/50 dark:border-[#1E2D42]/50">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#0F2B4C] to-[#1A3A5C] flex items-center justify-center">
                        <MessageSquare className="w-4 h-4 text-[var(--gold)]" />
                      </div>
                      <div>
                        <div className="font-bold text-sm text-[#0F2B4C] dark:text-[#E8ECF1]">{testimonial.name}</div>
                        <div className="text-xs text-muted-foreground">{testimonial.role}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mt-14"
        >
          <Card className="bg-gradient-to-r from-[#0F2B4C] to-[#1A3A5C] border-0 shadow-xl shadow-[#0F2B4C]/15 overflow-hidden">
            <CardContent className="p-8 md:p-12 text-center">
              <h3 className="text-xl md:text-2xl font-bold mb-3 text-white">هل تحتاج استشارة مهنية؟</h3>
              <p className="text-white/60 mb-6 max-w-lg mx-auto text-sm md:text-base">
                تواصل معي لمناقشة احتياجاتك في مجال الموارد البشرية والحصول على حلول مخصصة لمنظمتك
              </p>
              <Button
                onClick={() => onNavigate('contact')}
                size="lg"
                className="btn-academic bg-[var(--gold)] hover:bg-[#C9960E] text-[#0F2B4C] font-bold rounded-xl px-8 shadow-lg shadow-[var(--gold)]/20"
              >
                احجز استشارة الآن
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
