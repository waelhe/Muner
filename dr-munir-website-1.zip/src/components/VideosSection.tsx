'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, Filter } from 'lucide-react';
import { Input } from '@/components/ui/input';
import SectionTitle from '@/components/SectionTitle';
import VideoCard from '@/components/VideoCard';
import VideoDetailModal from '@/components/VideoDetailModal';

interface Video {
  id: string;
  title: string;
  description: string;
  category: string;
  type: string;
  url: string;
  thumbnail?: string;
  duration: string;
  transcript?: string;
  keyPoints?: string;
  tags?: string;
  featured: boolean;
  createdAt: string;
}

const categories = [
  { id: 'all', label: 'الكل' },
  { id: 'hr-kitchen', label: '🍳 مطبخ الموارد البشرية' },
  { id: 'job-skills', label: '🎯 مهارات سوق العمل' },
  { id: 'talent-management', label: 'إدارة المواهب' },
  { id: 'performance', label: 'تقييم الأداء' },
  { id: 'training', label: 'التدريب والتطوير' },
  { id: 'leadership', label: 'القيادة والإدارة' },
  { id: 'labor-law', label: 'قوانين العمل' },
  { id: 'career-tips', label: 'نصائح مهنية' },
];

export default function VideosSection() {
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [modalOpen, setModalOpen] = useState(false);

  useEffect(() => {
    fetch('/api/videos')
      .then(res => res.json())
      .then(data => {
        setVideos(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const filteredVideos = videos.filter(video => {
    const matchCategory = selectedCategory === 'all' || video.category === selectedCategory;
    const matchSearch = video.title.includes(searchQuery) || video.description.includes(searchQuery);
    return matchCategory && matchSearch;
  });

  if (loading) {
    return (
      <div className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="animate-pulse">
            <div className="h-8 bg-secondary rounded w-48 mx-auto mb-6" />
            <div className="flex flex-col sm:flex-row gap-3 mb-8 max-w-3xl mx-auto">
              <div className="h-11 bg-secondary rounded-xl flex-1" />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {[1, 2, 3, 4, 5, 6].map(i => (
                <div key={i} className="rounded-xl overflow-hidden">
                  <div className="h-40 bg-secondary rounded-t-xl" />
                  <div className="p-4 space-y-3">
                    <div className="h-3 bg-secondary rounded w-20" />
                    <div className="h-5 bg-secondary rounded w-3/4" />
                    <div className="h-4 bg-secondary rounded w-full" />
                    <div className="h-4 bg-secondary rounded w-5/6" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <SectionTitle title="المرئيات والإرشادات" subtitle="فيديوهات تعليمية وإرشادية في مجال الموارد البشرية" />

        {/* Search and Filter */}
        <div className="flex flex-col gap-3 mb-8 max-w-3xl mx-auto">
          <div className="relative w-full sm:flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="ابحث في الفيديوهات..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10 rounded-xl border-0 shadow-md shadow-[#0F2B4C]/5 dark:shadow-black/20 bg-white dark:bg-[#111B2B] h-11"
            />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide pb-1 -mx-4 px-4 sm:mx-0 sm:px-0">
            <Filter className="w-4 h-4 text-muted-foreground shrink-0" />
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`whitespace-nowrap px-4 py-2 rounded-xl text-xs font-medium transition-all duration-300 touch-target ${
                  selectedCategory === cat.id
                    ? 'bg-[#0F2B4C] dark:bg-[#4A8BC2] text-white shadow-md shadow-[#0F2B4C]/20 dark:shadow-black/30'
                    : 'bg-white dark:bg-[#111B2B] text-muted-foreground hover:bg-[#0F2B4C]/5 dark:hover:bg-white/5 hover:text-[#0F2B4C] dark:hover:text-[#E8ECF1] shadow-sm'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Video Grid */}
        {filteredVideos.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredVideos.map((video) => (
              <VideoCard
                key={video.id}
                video={video}
                onClick={(v) => {
                  setSelectedVideo(v);
                  setModalOpen(true);
                }}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 text-muted-foreground">
            <p className="text-lg">لا توجد فيديوهات مطابقة للبحث</p>
          </div>
        )}
      </div>

      {/* Video Detail Modal */}
      <VideoDetailModal
        video={selectedVideo}
        open={modalOpen}
        onClose={() => {
          setModalOpen(false);
          setSelectedVideo(null);
        }}
      />
    </div>
  );
}
