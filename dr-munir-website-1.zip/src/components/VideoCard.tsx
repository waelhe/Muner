'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Play, Clock, FileText } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface Video {
  id: string;
  title: string;
  description: string;
  category: string;
  type: string;
  url: string;
  thumbnail?: string;
  duration: string;
  transcript?: string;
  keyPoints?: string;
  tags?: string;
  featured: boolean;
  createdAt: string;
}

interface VideoCardProps {
  video: Video;
  onClick: (video: Video) => void;
}

const categoryLabels: Record<string, string> = {
  'talent-management': 'إدارة المواهب',
  'performance': 'تقييم الأداء',
  'training': 'التدريب والتطوير',
  'leadership': 'القيادة والإدارة',
  'labor-law': 'قوانين العمل',
  'career-tips': 'نصائح مهنية',
  'hr-kitchen': 'مطبخ الموارد البشرية',
  'job-skills': 'مهارات سوق العمل',
};

const categoryStyles: Record<string, { bg: string; text: string }> = {
  'talent-management': { bg: 'bg-blue-50', text: 'text-blue-700' },
  'performance': { bg: 'bg-emerald-50', text: 'text-emerald-700' },
  'training': { bg: 'bg-violet-50', text: 'text-violet-700' },
  'leadership': { bg: 'bg-amber-50', text: 'text-amber-700' },
  'labor-law': { bg: 'bg-red-50', text: 'text-red-700' },
  'career-tips': { bg: 'bg-teal-50', text: 'text-teal-700' },
  'hr-kitchen': { bg: 'bg-orange-50', text: 'text-orange-700' },
  'job-skills': { bg: 'bg-cyan-50', text: 'text-cyan-700' },
};

function getYouTubeId(url: string): string | null {
  if (!url) return null;
  const match = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([^&\s?]+)/);
  return match ? match[1] : null;
}

function getYouTubeThumbnail(url: string, quality: 'maxres' | 'hq' | 'mq' | 'sd' = 'hq'): string | null {
  const videoId = getYouTubeId(url);
  if (!videoId) return null;
  const qualityMap: Record<string, string> = {
    'maxres': 'maxresdefault.jpg',
    'hq': 'hqdefault.jpg',
    'mq': 'mqdefault.jpg',
    'sd': 'sddefault.jpg',
  };
  return `https://img.youtube.com/vi/${videoId}/${qualityMap[quality]}`;
}

export default function VideoCard({ video, onClick }: VideoCardProps) {
  const isShort = video.type === 'short';
  const style = categoryStyles[video.category] || { bg: 'bg-gray-50', text: 'text-gray-700' };
  const youtubeThumbnail = getYouTubeThumbnail(video.url, 'hq');
  const [imageError, setImageError] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [fallbackAttempted, setFallbackAttempted] = useState(false);
  const showThumbnail = youtubeThumbnail && !imageError;

  const handleImageError = () => {
    if (!fallbackAttempted && youtubeThumbnail) {
      // Try lower quality fallback
      const fallbackUrl = getYouTubeThumbnail(video.url, 'mq');
      if (fallbackUrl && fallbackUrl !== youtubeThumbnail) {
        setFallbackAttempted(true);
        const img = document.querySelector(`img[src="${youtubeThumbnail}"]`) as HTMLImageElement;
        if (img) {
          img.src = fallbackUrl;
          return;
        }
      }
    }
    setImageError(true);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4 }}
    >
      <Card
        className={`cursor-pointer group card-hover border-0 shadow-md shadow-[#0F2B4C]/5 dark:shadow-black/20 bg-white dark:bg-[#111B2B] overflow-hidden ${
          isShort ? 'max-w-[240px]' : ''
        }`}
        onClick={() => onClick(video)}
      >
        {/* Thumbnail */}
        <div className={`relative overflow-hidden ${
          isShort ? 'aspect-[9/16]' : 'aspect-video'
        }`}>
          {/* YouTube Thumbnail or Gradient Fallback */}
          {showThumbnail ? (
            <>
              {/* Loading skeleton */}
              {!imageLoaded && (
                <div className="absolute inset-0 bg-gradient-to-br from-[#0F2B4C] via-[#162D50] to-[#1A3A5C] animate-pulse" />
              )}
              <img
                src={youtubeThumbnail!}
                alt={video.title}
                className={`w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 ${
                  imageLoaded ? 'opacity-100' : 'opacity-0'
                }`}
                onLoad={() => setImageLoaded(true)}
                onError={handleImageError}
                loading="lazy"
              />
              {/* Dark overlay for better text/button visibility */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
            </>
          ) : (
            <div className="absolute inset-0 bg-gradient-to-br from-[#0F2B4C] via-[#162D50] to-[#1A3A5C]">
              {/* Decorative pattern */}
              <div className="absolute inset-0 opacity-10" style={{
                backgroundImage: `radial-gradient(circle at 30% 40%, rgba(184, 134, 11, 0.3) 0%, transparent 50%), radial-gradient(circle at 70% 60%, rgba(46, 109, 164, 0.2) 0%, transparent 50%)`
              }} />
              {/* Video title as placeholder text */}
              <div className="absolute inset-0 flex items-center justify-center p-4">
                <p className="text-white/40 text-sm text-center font-medium leading-relaxed line-clamp-3">{video.title}</p>
              </div>
            </div>
          )}

          {/* Play button overlay */}
          <div className="absolute inset-0 flex items-center justify-center z-10">
            <div className="w-14 h-14 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center group-hover:bg-white/35 group-hover:scale-110 transition-all duration-300 shadow-lg border border-white/20">
              <Play className="w-6 h-6 text-white fill-white" />
            </div>
          </div>

          {/* Duration badge */}
          <div className="absolute bottom-2 left-2 flex items-center gap-1 bg-black/70 backdrop-blur-sm text-white text-xs px-2.5 py-1 rounded-lg z-10">
            <Clock className="w-3 h-3" />
            {video.duration}
          </div>

          {/* Featured badge */}
          {video.featured && (
            <div className="absolute top-2 right-2 bg-[var(--gold)] text-[#0F2B4C] text-xs px-2.5 py-1 rounded-lg font-bold shadow-md z-10">
              مميز
            </div>
          )}

          {/* Hover overlay */}
          <div className="absolute inset-0 bg-[var(--gold)]/0 group-hover:bg-[var(--gold)]/10 transition-colors duration-300 z-10" />
        </div>

        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <span className={`text-[10px] px-2 py-0.5 rounded-md font-medium ${style.bg} ${style.text}`}>
              {categoryLabels[video.category] || video.category}
            </span>
          </div>
          <h3 className="font-bold text-sm md:text-base text-[#0F2B4C] dark:text-[#E8ECF1] line-clamp-2 mb-2 group-hover:text-[var(--gold)] transition-colors leading-relaxed">
            {video.title}
          </h3>
          {!isShort && (
            <p className="text-muted-foreground text-xs md:text-sm line-clamp-2 leading-relaxed">
              {video.description}
            </p>
          )}
          <div className="flex items-center gap-2 mt-3">
            {video.transcript && (
              <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
                <FileText className="w-3 h-3" />
                نسخة مكتوبة
              </span>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
