'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send, Youtube, Facebook, Linkedin, BookOpen, GraduationCap, CheckCircle, ExternalLink } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import SectionTitle from '@/components/SectionTitle';

interface Profile {
  id: string;
  name: string;
  title: string;
  bio: string;
  email: string;
  phone: string;
  address: string;
  youtube: string;
  facebook: string;
  facebookPage: string;
  linkedin: string;
  researchGate: string;
  googleScholar: string;
}

const socialConfig: Record<string, { bg: string; icon: string; hover: string }> = {
  youtube: { bg: 'bg-red-50', icon: 'text-red-600', hover: 'hover:border-red-300' },
  facebook: { bg: 'bg-blue-50', icon: 'text-blue-600', hover: 'hover:border-blue-300' },
  facebookPage: { bg: 'bg-blue-50', icon: 'text-blue-700', hover: 'hover:border-blue-300' },
  linkedin: { bg: 'bg-sky-50', icon: 'text-sky-700', hover: 'hover:border-sky-300' },
  researchGate: { bg: 'bg-emerald-50', icon: 'text-emerald-700', hover: 'hover:border-emerald-300' },
  googleScholar: { bg: 'bg-red-50', icon: 'text-red-700', hover: 'hover:border-red-300' },
};

export default function ContactSection() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetch('/api/profile')
      .then(res => res.json())
      .then(data => setProfile(data))
      .catch(() => {});
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');

    try {
      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        setSubmitted(true);
        setFormData({ name: '', email: '', subject: '', message: '' });
        setTimeout(() => setSubmitted(false), 5000);
      } else {
        setError('فشل إرسال الرسالة. يرجى المحاولة مرة أخرى.');
      }
    } catch {
      setError('حدث خطأ في الاتصال. يرجى المحاولة مرة أخرى.');
    } finally {
      setSubmitting(false);
    }
  };

  const socialLinks = [
    ...(profile?.youtube ? [{ href: profile.youtube, icon: Youtube, label: 'YouTube', key: 'youtube' as const }] : []),
    ...(profile?.facebook ? [{ href: profile.facebook, icon: Facebook, label: 'Facebook', key: 'facebook' as const }] : []),
    ...(profile?.facebookPage ? [{ href: profile.facebookPage, icon: Facebook, label: 'صفحة فيسبوك', key: 'facebookPage' as const }] : []),
    ...(profile?.linkedin ? [{ href: profile.linkedin, icon: Linkedin, label: 'LinkedIn', key: 'linkedin' as const }] : []),
    ...(profile?.researchGate ? [{ href: profile.researchGate, icon: BookOpen, label: 'ResearchGate', key: 'researchGate' as const }] : []),
    ...(profile?.googleScholar ? [{ href: profile.googleScholar, icon: GraduationCap, label: 'Google Scholar', key: 'googleScholar' as const }] : []),
  ];

  return (
    <div className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <SectionTitle title="تواصل معي" subtitle="يسعدني تواصلكم معي لأي استفسار أو استشارة" />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8 max-w-6xl mx-auto">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="lg:col-span-2"
          >
            <Card className="border-0 shadow-xl shadow-[#0F2B4C]/8 dark:shadow-black/20 dark:bg-[#111B2B] overflow-hidden">
              <div className="h-1 bg-gradient-to-r from-[#0F2B4C] via-[var(--gold)] to-[#0F2B4C]" />
              <CardContent className="p-6 md:p-8">
                {submitted ? (
                  <div className="text-center py-12">
                    <div className="w-20 h-20 rounded-full bg-green-50 flex items-center justify-center mx-auto mb-5">
                      <CheckCircle className="w-10 h-10 text-green-500" />
                    </div>
                    <h3 className="text-xl font-bold text-[#0F2B4C] dark:text-[#E8ECF1] mb-2">تم إرسال رسالتك بنجاح!</h3>
                    <p className="text-muted-foreground">سأقوم بالرد عليك في أقرب وقت ممكن.</p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name" className="text-sm font-medium text-[#0F2B4C] dark:text-[#E8ECF1]">الاسم الكامل</Label>
                        <Input
                          id="name"
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          placeholder="أدخل اسمك الكامل"
                          required
                          className="rounded-xl border-[#E0E6EF] dark:border-[#1E2D42] h-11 focus:border-[var(--gold)]"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-sm font-medium text-[#0F2B4C] dark:text-[#E8ECF1]">البريد الإلكتروني</Label>
                        <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          placeholder="أدخل بريدك الإلكتروني"
                          required
                          className="rounded-xl border-[#E0E6EF] dark:border-[#1E2D42] h-11 focus:border-[var(--gold)]"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="subject" className="text-sm font-medium text-[#0F2B4C] dark:text-[#E8ECF1]">الموضوع</Label>
                      <Input
                        id="subject"
                        value={formData.subject}
                        onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                        placeholder="موضوع الرسالة"
                        required
                        className="rounded-xl border-[#E0E6EF] dark:border-[#1E2D42] h-11 focus:border-[var(--gold)]"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="message" className="text-sm font-medium text-[#0F2B4C] dark:text-[#E8ECF1]">الرسالة</Label>
                      <Textarea
                        id="message"
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        placeholder="اكتب رسالتك هنا..."
                        rows={5}
                        required
                        className="rounded-xl border-[#E0E6EF] dark:border-[#1E2D42] focus:border-[var(--gold)]"
                      />
                    </div>
                    {error && (
                      <p className="text-red-500 text-sm">{error}</p>
                    )}
                    <Button
                      type="submit"
                      disabled={submitting}
                      className="w-full bg-gradient-to-r from-[#0F2B4C] to-[#1A3A5C] hover:from-[#0F2B4C] hover:to-[#0F2B4C] gap-2 rounded-xl h-12 text-base font-semibold shadow-lg shadow-[#0F2B4C]/20"
                    >
                      <Send className="w-4 h-4" />
                      {submitting ? 'جاري الإرسال...' : 'إرسال الرسالة'}
                    </Button>
                  </form>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="space-y-5"
          >
            {/* Contact Details Card */}
            <Card className="border-0 shadow-lg shadow-[#0F2B4C]/5 dark:shadow-black/20 dark:bg-[#111B2B] overflow-hidden">
              <div className="h-1 bg-gradient-to-r from-[var(--gold)] to-[var(--accent-blue)]" />
              <CardContent className="p-6">
                <h3 className="font-bold text-lg text-[#0F2B4C] dark:text-[#E8ECF1] mb-5">معلومات التواصل</h3>
                <ul className="space-y-5">
                  {[
                    { icon: Mail, label: 'البريد الإلكتروني', value: profile?.email || 'Munir.Abas@spu.edu.sy' },
                    { icon: Phone, label: 'الهاتف', value: profile?.phone || '+963-94-304-3821' },
                    { icon: MapPin, label: 'العنوان', value: profile?.address || 'دمشق، سورية' },
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-xl bg-[#0F2B4C]/8 dark:bg-white/10 flex items-center justify-center shrink-0">
                        <item.icon className="w-4 h-4 text-[#0F2B4C] dark:text-[#E8ECF1]" />
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground font-medium mb-0.5">{item.label}</div>
                        <div className="text-sm font-medium text-[#0F2B4C] dark:text-[#E8ECF1]">{item.value}</div>
                      </div>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Social Links Card */}
            <Card className="border-0 shadow-lg shadow-[#0F2B4C]/5 dark:shadow-black/20 dark:bg-[#111B2B] overflow-hidden">
              <div className="h-1 bg-gradient-to-r from-[var(--accent-blue)] to-[#0F2B4C]" />
              <CardContent className="p-6">
                <h3 className="font-bold text-lg text-[#0F2B4C] dark:text-[#E8ECF1] mb-5">تابعني على</h3>
                <div className="space-y-2.5">
                  {socialLinks.map((link, index) => {
                    const config = socialConfig[link.key] || { bg: 'bg-gray-50', icon: 'text-gray-700', hover: '' };
                    return (
                      <motion.a
                        key={link.label}
                        href={link.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        initial={{ opacity: 0, x: 20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.3, delay: index * 0.08 }}
                        className={`flex items-center gap-3 p-3 rounded-xl border border-transparent ${config.hover} hover:bg-white/50 dark:hover:bg-white/5 transition-all duration-200 touch-target`}
                      >
                        <div className={`w-9 h-9 rounded-lg ${config.bg} flex items-center justify-center`}>
                          <link.icon className={`w-4 h-4 ${config.icon}`} />
                        </div>
                        <span className="text-sm font-medium text-foreground/80">{link.label}</span>
                        <ExternalLink className="w-3 h-3 text-muted-foreground mr-auto opacity-0 group-hover:opacity-100" />
                      </motion.a>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Map Card */}
            <Card className="border-0 shadow-lg shadow-[#0F2B4C]/5 dark:shadow-black/20 dark:bg-[#111B2B] overflow-hidden">
              <CardContent className="p-0">
                <div className="h-48 bg-gradient-to-br from-[#0F2B4C]/5 dark:from-white/5 to-[var(--gold)]/5 dark:to-[var(--gold)]/5 flex items-center justify-center rounded-xl">
                  <div className="text-center">
                    <div className="w-14 h-14 rounded-full bg-[#0F2B4C]/10 dark:bg-white/10 flex items-center justify-center mx-auto mb-3">
                      <MapPin className="w-6 h-6 text-[#0F2B4C]/60 dark:text-[#8A9BB5]" />
                    </div>
                    <p className="text-sm font-medium text-[#0F2B4C]/60 dark:text-[#8A9BB5]">{profile?.address || 'دمشق، سورية'}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
