'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Award, BookOpen, Lightbulb, ChevronLeft, ShieldCheck, Globe2, Briefcase } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import SectionTitle from '@/components/SectionTitle';
import TimelineItem from '@/components/TimelineItem';
import Image from 'next/image';

interface Profile {
  id: string;
  name: string;
  title: string;
  bio: string;
  qualifications: { degree: string; specialization: string; institution: string; year: string }[];
  experience: { title: string; place: string; period: string; description: string }[];
  philosophy: string;
  researchInterests: string[];
  certifications: { name: string; issuer: string }[];
  email: string;
  phone: string;
  address: string;
}

export default function AboutSection() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/profile')
      .then(res => res.json())
      .then(data => {
        setProfile(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="animate-pulse">
            {/* Profile card skeleton */}
            <div className="bg-card rounded-2xl shadow-md overflow-hidden mb-12">
              <div className="h-2 bg-secondary rounded" />
              <div className="flex flex-col md:flex-row">
                <div className="md:w-[280px] h-[250px] md:h-[360px] bg-secondary" />
                <div className="flex-1 p-6 md:p-8 space-y-4">
                  <div className="h-3 bg-secondary rounded w-20" />
                  <div className="h-7 bg-secondary rounded w-3/4" />
                  <div className="h-5 bg-secondary rounded w-1/2" />
                  <div className="h-4 bg-secondary rounded w-full" />
                  <div className="h-4 bg-secondary rounded w-5/6" />
                  <div className="h-4 bg-secondary rounded w-4/6" />
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4">
                    {[1, 2, 3].map(i => (
                      <div key={i} className="h-14 bg-secondary rounded-xl" />
                    ))}
                  </div>
                </div>
              </div>
            </div>
            {/* Qualifications skeleton */}
            <div className="mb-12">
              <div className="flex items-center gap-3 mb-8">
                <div className="w-10 h-10 rounded-xl bg-secondary" />
                <div className="space-y-2">
                  <div className="h-6 bg-secondary rounded w-48" />
                  <div className="h-1 bg-secondary rounded w-16" />
                </div>
              </div>
              <div className="grid md:grid-cols-3 gap-5">
                {[1, 2, 3].map(i => (
                  <div key={i} className="h-32 bg-secondary rounded-xl" />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!profile) return null;

  return (
    <div className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <SectionTitle title="عني" subtitle="تعرف على مسيرتي الأكاديمية والمهنية" />

        {/* Profile Header - Premium Layout */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="relative mb-16"
        >
          <Card className="overflow-hidden border-0 shadow-xl shadow-[#0F2B4C]/8 dark:shadow-black/20 dark:bg-[#111B2B]">
            <div className="relative">
              {/* Top gradient bar */}
              <div className="h-2 bg-gradient-to-r from-[#0F2B4C] via-[var(--gold)] to-[#0F2B4C]" />
              
              <CardContent className="p-0">
                <div className="flex flex-col md:flex-row">
                  {/* Photo Section */}
                  <div className="relative md:w-[280px] lg:w-[320px] shrink-0">
                    <div className="relative h-[220px] sm:h-[260px] md:h-full md:min-h-[360px] overflow-hidden">
                      <Image
                        src="/dr-munir-hero.png"
                        alt="أستاذ دكتور منير عباس"
                        fill
                        className="object-cover object-top"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#0F2B4C]/40 via-transparent to-transparent" />
                      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-[var(--gold)] to-[var(--accent-blue)]" />
                    </div>
                  </div>
                  
                  {/* Info Section */}
                  <div className="flex-1 p-6 md:p-8 lg:p-10">
                    <div className="flex items-center gap-2 mb-4">
                      <div className="w-2 h-8 bg-[var(--gold)] rounded-full" />
                      <span className="text-[var(--gold)] font-bold text-sm tracking-wide">السيرة المهنية</span>
                    </div>
                    
                    <h3 className="text-2xl md:text-3xl font-bold text-[#0F2B4C] dark:text-[#E8ECF1] mb-2">
                      {profile.name}
                    </h3>
                    <p className="text-[var(--gold)] font-semibold text-lg mb-4">
                      {profile.title}
                    </p>
                    <p className="text-foreground/75 leading-[1.9] text-sm md:text-base mb-6">
                      {profile.bio}
                    </p>
                    
                    {/* Quick Info Cards */}
                    <div className="grid grid-cols-3 gap-2 sm:gap-3">
                      {[
                        { icon: Globe2, label: 'المقرر', value: 'دمشق، سورية' },
                        { icon: Briefcase, label: 'التخصص', value: 'إدارة الموارد البشرية' },
                        { icon: Award, label: 'اللقب', value: 'أستاذ دكتور' },
                      ].map((item, i) => (
                        <div key={i} className="flex flex-col sm:flex-row items-center sm:items-start gap-2 sm:gap-3 bg-[#0F2B4C]/5 dark:bg-white/5 rounded-xl px-3 py-3 sm:px-4 text-center sm:text-right">
                          <div className="w-8 h-8 rounded-lg bg-[#0F2B4C]/10 dark:bg-white/10 flex items-center justify-center shrink-0">
                            <item.icon className="w-4 h-4 text-[#0F2B4C] dark:text-[#E8ECF1]" />
                          </div>
                          <div>
                            <div className="text-[10px] text-muted-foreground font-medium">{item.label}</div>
                            <div className="text-xs sm:text-sm font-bold text-[#0F2B4C] dark:text-[#E8ECF1]">{item.value}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </div>
          </Card>
        </motion.div>

        {/* Qualifications */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-16"
        >
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-xl bg-[var(--gold)]/10 flex items-center justify-center">
              <Award className="w-5 h-5 text-[var(--gold)]" />
            </div>
            <div>
              <h3 className="text-xl md:text-2xl font-bold text-[#0F2B4C] dark:text-[#E8ECF1]">المؤهلات الأكاديمية</h3>
              <div className="h-0.5 w-16 bg-gradient-to-r from-[var(--gold)] to-transparent mt-1" />
            </div>
          </div>
          <div className="grid md:grid-cols-3 gap-5">
            {profile.qualifications?.map((qual, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
              >
                <Card className="h-full card-hover-academic border-0 shadow-md shadow-[#0F2B4C]/5 dark:shadow-black/20 dark:bg-[#111B2B]">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0F2B4C] to-[#1A3A5C] flex items-center justify-center shrink-0 shadow-md shadow-[#0F2B4C]/20 dark:shadow-black/30">
                        <BookOpen className="w-5 h-5 text-[var(--gold)]" />
                      </div>
                      <div>
                        <h4 className="font-bold text-[#0F2B4C] dark:text-[#E8ECF1] text-base mb-1">{qual.degree}</h4>
                        <p className="text-[var(--gold)] text-sm font-semibold mb-1">{qual.specialization}</p>
                        <p className="text-muted-foreground text-sm">{qual.institution}</p>
                        {qual.year && (
                          <Badge className="mt-2 bg-[#0F2B4C]/8 dark:bg-white/10 text-[#0F2B4C] dark:text-[#E8ECF1] hover:bg-[#0F2B4C]/12 dark:hover:bg-white/15 text-xs border-0">
                            {qual.year}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Certifications */}
        {profile.certifications && profile.certifications.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="mb-16"
          >
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 rounded-xl bg-[var(--gold)]/10 flex items-center justify-center">
                <ShieldCheck className="w-5 h-5 text-[var(--gold)]" />
              </div>
              <div>
                <h3 className="text-xl md:text-2xl font-bold text-[#0F2B4C] dark:text-[#E8ECF1]">الشهادات والاعتمادات المهنية</h3>
                <div className="h-0.5 w-16 bg-gradient-to-r from-[var(--gold)] to-transparent mt-1" />
              </div>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
              {profile.certifications.map((cert, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: index * 0.08 }}
                >
                  <Card className="h-full card-hover-academic border-0 shadow-md shadow-[#0F2B4C]/5 dark:shadow-black/20 dark:bg-[#111B2B]">
                    <CardContent className="p-5">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[var(--gold)]/20 to-[var(--gold)]/5 flex items-center justify-center shrink-0">
                          <ShieldCheck className="w-5 h-5 text-[var(--gold)]" />
                        </div>
                        <div>
                          <h4 className="font-bold text-[#0F2B4C] dark:text-[#E8ECF1] text-sm mb-1">{cert.name}</h4>
                          <p className="text-muted-foreground text-xs leading-relaxed">{cert.issuer}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Experience Timeline */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-16"
        >
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-xl bg-[var(--gold)]/10 flex items-center justify-center">
              <ChevronLeft className="w-5 h-5 text-[var(--gold)]" />
            </div>
            <div>
              <h3 className="text-xl md:text-2xl font-bold text-[#0F2B4C] dark:text-[#E8ECF1]">الخبرة المهنية</h3>
              <div className="h-0.5 w-16 bg-gradient-to-r from-[var(--gold)] to-transparent mt-1" />
            </div>
          </div>
          <div className="max-w-3xl">
            {profile.experience?.map((exp, index) => (
              <TimelineItem
                key={index}
                title={exp.title}
                place={exp.place}
                period={exp.period}
                description={exp.description}
                index={index}
              />
            ))}
          </div>
        </motion.div>

        {/* Philosophy & Research Interests */}
        <div className="grid md:grid-cols-2 gap-6">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <Card className="h-full border-0 shadow-lg shadow-[#0F2B4C]/5 dark:shadow-black/20 dark:bg-[#111B2B] overflow-hidden">
              <div className="h-1 bg-gradient-to-r from-[var(--gold)] to-[var(--accent-blue)]" />
              <CardContent className="p-6 md:p-8">
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-10 h-10 rounded-xl bg-[var(--gold)]/10 flex items-center justify-center">
                    <Lightbulb className="w-5 h-5 text-[var(--gold)]" />
                  </div>
                  <h3 className="text-lg font-bold text-[#0F2B4C] dark:text-[#E8ECF1]">فلسفتي المهنية</h3>
                </div>
                <p className="text-foreground/75 leading-[1.9] text-sm md:text-base italic relative">
                  <span className="text-[var(--gold)] text-4xl absolute -top-2 -right-1 opacity-20 font-serif">&ldquo;</span>
                  <span className="relative z-10 pr-4">{profile.philosophy}</span>
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <Card className="h-full border-0 shadow-lg shadow-[#0F2B4C]/5 dark:shadow-black/20 dark:bg-[#111B2B] overflow-hidden">
              <div className="h-1 bg-gradient-to-r from-[var(--accent-blue)] to-[#0F2B4C]" />
              <CardContent className="p-6 md:p-8">
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-10 h-10 rounded-xl bg-[#0F2B4C]/10 dark:bg-white/10 flex items-center justify-center">
                    <BookOpen className="w-5 h-5 text-[#0F2B4C] dark:text-[#E8ECF1]" />
                  </div>
                  <h3 className="text-lg font-bold text-[#0F2B4C] dark:text-[#E8ECF1]">اهتمامات البحثية</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {profile.researchInterests?.map((interest, index) => (
                    <Badge
                      key={index}
                      className="bg-[#0F2B4C]/8 dark:bg-white/10 text-[#0F2B4C] dark:text-[#E8ECF1] hover:bg-[#0F2B4C]/15 dark:hover:bg-white/15 transition-colors cursor-default border-0 px-3 py-1.5 text-sm font-medium"
                    >
                      {interest}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
