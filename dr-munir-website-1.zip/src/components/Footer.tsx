'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Youtube, Facebook, Linkedin, BookOpen, GraduationCap, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Profile {
  id: string;
  name: string;
  title: string;
  bio: string;
  email: string;
  phone: string;
  address: string;
  youtube: string;
  facebook: string;
  facebookPage: string;
  linkedin: string;
  researchGate: string;
  googleScholar: string;
}

interface FooterProps {
  onNavigate: (page: string) => void;
  onAdminClick: () => void;
}

export default function Footer({ onNavigate, onAdminClick }: FooterProps) {
  const [profile, setProfile] = useState<Profile | null>(null);

  useEffect(() => {
    fetch('/api/profile')
      .then(res => res.json())
      .then(data => setProfile(data))
      .catch(() => {});
  }, []);

  const handleNavigate = (page: string) => {
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const socialLinks = [
    ...(profile?.youtube ? [{ href: profile.youtube, icon: Youtube, label: 'YouTube', color: 'hover:bg-red-500' }] : []),
    ...(profile?.facebook ? [{ href: profile.facebook, icon: Facebook, label: 'Facebook', color: 'hover:bg-blue-600' }] : []),
    ...(profile?.facebookPage ? [{ href: profile.facebookPage, icon: Facebook, label: 'صفحة فيسبوك', color: 'hover:bg-blue-700' }] : []),
    ...(profile?.linkedin ? [{ href: profile.linkedin, icon: Linkedin, label: 'LinkedIn', color: 'hover:bg-blue-700' }] : []),
    ...(profile?.researchGate ? [{ href: profile.researchGate, icon: BookOpen, label: 'ResearchGate', color: 'hover:bg-green-700' }] : []),
    ...(profile?.googleScholar ? [{ href: profile.googleScholar, icon: GraduationCap, label: 'Google Scholar', color: 'hover:bg-red-700' }] : []),
  ];

  return (
    <footer className="relative mt-auto overflow-hidden">
      {/* Top gradient border */}
      <div className="h-1 bg-gradient-to-r from-[#0F2B4C] via-[var(--gold)] to-[#0F2B4C]" />
      
      <div className="bg-gradient-to-b from-[#0F2B4C] to-[#091A30] text-white">
        <div className="container mx-auto px-4 py-12 md:py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 md:gap-8">
            {/* About */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="lg:col-span-1"
            >
              <div className="flex items-center gap-3 mb-5">
                <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[var(--gold)] to-[#C9960E] flex items-center justify-center shadow-md shadow-[var(--gold)]/20">
                  <GraduationCap className="w-5 h-5 text-[#0F2B4C]" />
                </div>
                <div>
                  <div className="font-bold text-base">{profile?.name || 'أستاذ دكتور منير عباس'}</div>
                  <div className="text-white/50 text-xs">{profile?.title || 'إدارة الموارد البشرية'}</div>
                </div>
              </div>
              <p className="text-white/60 text-sm leading-relaxed mb-5">
                {profile?.bio ? profile.bio.substring(0, 150) + '...' : 'أكاديمي واستشاري متخصص في إدارة الموارد البشرية، بخبرة تزيد عن 25 عاماً في التدريس والاستشارات.'}
              </p>
              <div className="flex items-center gap-2 flex-wrap">
                {socialLinks.map((link) => (
                  <a
                    key={link.label}
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`w-9 h-9 rounded-lg bg-white/8 ${link.color} flex items-center justify-center transition-all duration-300 hover:shadow-lg`}
                    aria-label={link.label}
                  >
                    <link.icon className="w-4 h-4" />
                  </a>
                ))}
              </div>
            </motion.div>

            {/* Quick Links */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <h3 className="font-bold text-base mb-5 text-[var(--gold)] flex items-center gap-2">
                <div className="w-1 h-5 bg-[var(--gold)] rounded-full" />
                روابط سريعة
              </h3>
              <ul className="space-y-2.5">
                {[
                  { id: 'home', label: 'الرئيسية' },
                  { id: 'about', label: 'عني' },
                  { id: 'research', label: 'الأبحاث' },
                  { id: 'videos', label: 'المرئيات' },
                  { id: 'courses', label: 'المقررات' },
                  { id: 'consultations', label: 'الاستشارات' },
                  { id: 'contact', label: 'تواصل معي' },
                ].map((item) => (
                  <li key={item.id}>
                    <button
                      onClick={() => handleNavigate(item.id)}
                      className="text-white/60 hover:text-[var(--gold)] transition-colors text-sm hover:pr-2 duration-200"
                    >
                      {item.label}
                    </button>
                  </li>
                ))}
              </ul>
            </motion.div>

            {/* External Links */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.15 }}
            >
              <h3 className="font-bold text-base mb-5 text-[var(--gold)] flex items-center gap-2">
                <div className="w-1 h-5 bg-[var(--gold)] rounded-full" />
                منصات أكاديمية
              </h3>
              <ul className="space-y-2.5">
                {[
                  { label: 'ResearchGate', href: profile?.researchGate },
                  { label: 'Google Scholar', href: profile?.googleScholar },
                  { label: 'LinkedIn', href: profile?.linkedin },
                  { label: 'قناة اليوتيوب', href: profile?.youtube },
                  { label: 'مؤسسة IHRM Syria', href: 'https://ihrmsyria.org' },
                ].filter(item => item.href).map((item) => (
                  <li key={item.label}>
                    <a
                      href={item.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-white/60 hover:text-[var(--gold)] transition-colors text-sm group"
                    >
                      <ExternalLink className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                      {item.label}
                    </a>
                  </li>
                ))}
              </ul>
            </motion.div>

            {/* Contact Info */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <h3 className="font-bold text-base mb-5 text-[var(--gold)] flex items-center gap-2">
                <div className="w-1 h-5 bg-[var(--gold)] rounded-full" />
                تواصل معنا
              </h3>
              <ul className="space-y-4">
                <li className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-white/8 flex items-center justify-center shrink-0">
                    <Mail className="w-4 h-4 text-[var(--gold)]" />
                  </div>
                  <span className="text-white/60 text-sm">{profile?.email || 'Munir.Abas@spu.edu.sy'}</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-white/8 flex items-center justify-center shrink-0">
                    <Phone className="w-4 h-4 text-[var(--gold)]" />
                  </div>
                  <span className="text-white/60 text-sm">{profile?.phone || '+963-94-304-3821'}</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-white/8 flex items-center justify-center shrink-0">
                    <MapPin className="w-4 h-4 text-[var(--gold)]" />
                  </div>
                  <span className="text-white/60 text-sm">{profile?.address || 'دمشق، سورية'}</span>
                </li>
              </ul>
            </motion.div>
          </div>

          {/* Bottom bar */}
          <div className="mt-10 pt-6 border-t border-white/8 flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="text-white/40 text-xs">
              &copy; {new Date().getFullYear()} {profile?.name || 'أستاذ دكتور منير عباس'}. جميع الحقوق محفوظة.
            </p>
            <button
              onClick={onAdminClick}
              className="text-white/20 hover:text-white/40 text-xs transition-colors"
            >
              لوحة التحكم
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
