'use client';

import { motion } from 'framer-motion';
import { Briefcase } from 'lucide-react';

interface TimelineItemProps {
  title: string;
  place: string;
  period: string;
  description: string;
  index: number;
}

export default function TimelineItem({ title, place, period, description, index }: TimelineItemProps) {
  return (
    <motion.div
      initial={{ opacity: 0, x: index % 2 === 0 ? 30 : -30 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="relative pr-10 pb-8 last:pb-0"
    >
      {/* Timeline line */}
      <div className="absolute right-[7px] top-3 bottom-0 w-[2px] bg-gradient-to-b from-[var(--gold)] via-[#0F2B4C]/30 to-[var(--gold)]/30" />
      
      {/* Timeline dot */}
      <div className="absolute right-0 top-2 w-4 h-4 rounded-full bg-[#0F2B4C] border-[3px] border-[var(--gold)] shadow-md shadow-[var(--gold)]/20 z-10" />
      
      <div className="bg-white dark:bg-[#111B2B] rounded-xl border border-[#E0E6EF] dark:border-[#1E2D42] p-5 md:p-6 shadow-md shadow-[#0F2B4C]/5 dark:shadow-black/20 hover:shadow-lg hover:shadow-[#0F2B4C]/8 dark:hover:shadow-black/30 transition-all duration-300 card-hover-academic">
        <div className="flex items-start gap-3 mb-3">
          <div className="w-8 h-8 rounded-lg bg-[var(--gold)]/10 flex items-center justify-center shrink-0">
            <Briefcase className="w-4 h-4 text-[var(--gold)]" />
          </div>
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-2 mb-1">
              <span className="text-xs md:text-sm text-[var(--gold)] font-bold bg-[var(--gold)]/10 px-3 py-1 rounded-lg">
                {period}
              </span>
            </div>
            <h3 className="text-base md:text-lg font-bold text-[#0F2B4C] dark:text-[#E8ECF1] mb-1">{title}</h3>
            <p className="text-sm text-muted-foreground font-medium mb-2">{place}</p>
            <p className="text-sm text-foreground/70 leading-relaxed">{description}</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
