'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Download, Calendar, ChevronLeft } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import SectionTitle from '@/components/SectionTitle';

interface Course {
  id: string;
  title: string;
  description: string;
  semester?: string;
  materials?: string;
  status: string;
  createdAt: string;
}

export default function CoursesSection() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/courses')
      .then(res => res.json())
      .then(data => {
        setCourses(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="animate-pulse">
            <div className="h-8 bg-secondary rounded w-48 mx-auto mb-6" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 max-w-5xl mx-auto">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="bg-card rounded-xl overflow-hidden">
                  <div className="h-1 bg-secondary rounded" />
                  <div className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-14 h-14 rounded-xl bg-secondary shrink-0" />
                      <div className="flex-1 space-y-3">
                        <div className="flex items-center gap-2">
                          <div className="h-5 bg-secondary rounded w-2/3" />
                          <div className="h-5 bg-secondary rounded w-16" />
                        </div>
                        <div className="h-4 bg-secondary rounded w-full" />
                        <div className="h-4 bg-secondary rounded w-5/6" />
                        <div className="flex gap-2">
                          <div className="h-8 bg-secondary rounded-lg w-20" />
                          <div className="h-8 bg-secondary rounded-lg w-20" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <SectionTitle title="التدريس والمقررات" subtitle="المقررات الأكاديمية التي أقوم بتدريسها" />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 max-w-5xl mx-auto">
          {courses.map((course, index) => {
            const materials = course.materials ? JSON.parse(course.materials) : [];
            return (
              <motion.div
                key={course.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.08 }}
              >
                <Card className="h-full card-hover-academic border-0 shadow-md shadow-[#0F2B4C]/5 dark:shadow-black/20 bg-white dark:bg-[#111B2B] overflow-hidden">
                  <CardContent className="p-0">
                    {/* Top accent */}
                    <div className="h-1 bg-gradient-to-r from-[#0F2B4C] via-[var(--gold)] to-[#0F2B4C]" />
                    <div className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#0F2B4C] to-[#1A3A5C] flex items-center justify-center shrink-0 shadow-md shadow-[#0F2B4C]/20 dark:shadow-black/30">
                          <BookOpen className="w-6 h-6 text-[var(--gold)]" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex flex-wrap items-center gap-2 mb-2">
                            <h3 className="font-bold text-lg text-[#0F2B4C] dark:text-[#E8ECF1]">
                              {course.title}
                            </h3>
                            {course.semester && (
                              <Badge className="bg-[var(--gold)]/10 text-[var(--gold)] text-xs gap-1 border-0 font-medium">
                                <Calendar className="w-3 h-3" />
                                {course.semester}
                              </Badge>
                            )}
                          </div>
                          <p className="text-foreground/70 text-sm leading-relaxed mb-3">
                            {course.description}
                          </p>
                          {materials.length > 0 && (
                            <div className="flex flex-wrap gap-2">
                              {materials.map((mat: { name: string; url: string }, i: number) => (
                                <Button key={i} variant="outline" size="sm" className="gap-1 text-xs rounded-lg border-[#E0E6EF] dark:border-[#1E2D42] hover:border-[var(--gold)] hover:text-[var(--gold)]">
                                  <Download className="w-3 h-3" />
                                  {mat.name}
                                </Button>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
