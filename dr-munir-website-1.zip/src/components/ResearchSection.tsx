'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, ExternalLink, FileText, Filter } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import SectionTitle from '@/components/SectionTitle';

interface Research {
  id: string;
  title: string;
  abstract: string;
  category: string;
  fileUrl?: string;
  externalUrl?: string;
  tags?: string;
  featured: boolean;
  createdAt: string;
}

const categories = [
  { id: 'all', label: 'الكل' },
  { id: 'talent-management', label: 'إدارة المواهب' },
  { id: 'performance', label: 'تقييم الأداء' },
  { id: 'training', label: 'التدريب والتطوير' },
  { id: 'leadership', label: 'القيادة والإدارة' },
  { id: 'labor-law', label: 'قوانين العمل' },
];

const categoryLabels: Record<string, string> = {
  'talent-management': 'إدارة المواهب',
  'performance': 'تقييم الأداء',
  'training': 'التدريب والتطوير',
  'leadership': 'القيادة والإدارة',
  'labor-law': 'قوانين العمل',
};

const categoryStyles: Record<string, { bg: string; text: string; border: string }> = {
  'talent-management': { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200' },
  'performance': { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200' },
  'training': { bg: 'bg-violet-50', text: 'text-violet-700', border: 'border-violet-200' },
  'leadership': { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200' },
  'labor-law': { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200' },
};

export default function ResearchSection() {
  const [researches, setResearches] = useState<Research[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetch('/api/research')
      .then(res => res.json())
      .then(data => {
        setResearches(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const filteredResearch = researches.filter(research => {
    const matchCategory = selectedCategory === 'all' || research.category === selectedCategory;
    const matchSearch = research.title.includes(searchQuery) || research.abstract.includes(searchQuery);
    return matchCategory && matchSearch;
  });

  if (loading) {
    return (
      <div className="py-16 md:py-24 bg-[var(--warm-cream)] dark:bg-[#0A1220]">
        <div className="container mx-auto px-4">
          <div className="animate-pulse">
            <div className="h-8 bg-secondary rounded w-48 mx-auto mb-6" />
            <div className="flex flex-col sm:flex-row gap-3 mb-8 max-w-3xl mx-auto">
              <div className="h-11 bg-secondary rounded-xl flex-1" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="bg-card rounded-xl p-6 space-y-4">
                  <div className="flex items-center gap-2">
                    <div className="h-5 bg-secondary rounded w-20" />
                    <div className="h-5 bg-secondary rounded w-16" />
                  </div>
                  <div className="h-5 bg-secondary rounded w-3/4" />
                  <div className="h-4 bg-secondary rounded w-full" />
                  <div className="h-4 bg-secondary rounded w-5/6" />
                  <div className="h-4 bg-secondary rounded w-2/3" />
                  <div className="flex gap-2 pt-3">
                    <div className="h-5 bg-secondary rounded w-14" />
                    <div className="h-5 bg-secondary rounded w-14" />
                    <div className="h-5 bg-secondary rounded w-14" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-16 md:py-24 bg-[var(--warm-cream)] dark:bg-[#0A1220]">
      <div className="container mx-auto px-4">
        <SectionTitle title="الأبحاث والمنشورات" subtitle="أحدث الأبحاث والدراسات في مجال الموارد البشرية" />

        {/* Search and Filter */}
        <div className="flex flex-col gap-3 mb-8 max-w-3xl mx-auto">
          <div className="relative w-full sm:flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="ابحث في الأبحاث..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10 rounded-xl border-0 shadow-md shadow-[#0F2B4C]/5 dark:shadow-black/20 bg-white dark:bg-[#111B2B] h-11"
            />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide pb-1 -mx-4 px-4 sm:mx-0 sm:px-0">
            <Filter className="w-4 h-4 text-muted-foreground shrink-0" />
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`whitespace-nowrap px-4 py-2 rounded-xl text-xs font-medium transition-all duration-300 touch-target ${
                  selectedCategory === cat.id
                    ? 'bg-[#0F2B4C] dark:bg-[#4A8BC2] text-white shadow-md shadow-[#0F2B4C]/20 dark:shadow-black/30'
                    : 'bg-white dark:bg-[#111B2B] text-muted-foreground hover:bg-[#0F2B4C]/5 dark:hover:bg-white/5 hover:text-[#0F2B4C] dark:hover:text-[#E8ECF1] shadow-sm'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Research Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredResearch.map((research, index) => {
            const tags = research.tags ? JSON.parse(research.tags) : [];
            const style = categoryStyles[research.category] || { bg: 'bg-gray-50', text: 'text-gray-700', border: 'border-gray-200' };
            return (
              <motion.div
                key={research.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
              >
                <Card className="h-full card-hover-academic border-0 shadow-md shadow-[#0F2B4C]/5 dark:shadow-black/20 bg-white dark:bg-[#111B2B] overflow-hidden">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-2 mb-4">
                      <span className={`text-xs px-3 py-1 rounded-lg font-medium ${style.bg} ${style.text} border ${style.border}`}>
                        {categoryLabels[research.category] || research.category}
                      </span>
                      {research.featured && (
                        <Badge className="bg-[var(--gold)]/15 text-[var(--gold)] text-xs border-0 font-bold">
                          بحث مميز
                        </Badge>
                      )}
                    </div>

                    <h3 className="font-bold text-base md:text-lg text-[#0F2B4C] dark:text-[#E8ECF1] mb-3 group-hover:text-[var(--gold)] transition-colors leading-relaxed">
                      {research.title}
                    </h3>

                    <p className="text-muted-foreground text-sm leading-[1.8] mb-4 line-clamp-3">
                      {research.abstract}
                    </p>

                    <div className="flex items-center justify-between pt-3 border-t border-[#E0E6EF]/50 dark:border-[#1E2D42]/50">
                      <div className="flex flex-wrap gap-1.5">
                        {tags.slice(0, 3).map((tag: string, i: number) => (
                          <Badge key={i} variant="outline" className="text-[10px] border-[#E0E6EF] dark:border-[#1E2D42] text-muted-foreground">
                            {tag}
                          </Badge>
                        ))}
                      </div>

                      <div className="flex items-center gap-2">
                        {research.externalUrl && (
                          <a href={research.externalUrl} target="_blank" rel="noopener noreferrer">
                            <Button variant="ghost" size="sm" className="gap-1 text-xs hover:text-[var(--gold)]">
                              <ExternalLink className="w-3 h-3" />
                              رابط خارجي
                            </Button>
                          </a>
                        )}
                        {research.fileUrl && (
                          <Button variant="ghost" size="sm" className="gap-1 text-xs hover:text-[var(--gold)]">
                            <FileText className="w-3 h-3" />
                            تحميل
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {filteredResearch.length === 0 && (
          <div className="text-center py-16 text-muted-foreground">
            <FileText className="w-16 h-16 mx-auto mb-4 opacity-30" />
            <p className="text-lg">لا توجد أبحاث مطابقة للبحث</p>
          </div>
        )}
      </div>
    </div>
  );
}
