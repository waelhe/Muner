'use client';

import { useState, useEffect, useCallback } from 'react';
import {
  X, LayoutDashboard, Video, FileText, BookOpen, MessageSquare,
  Settings, Plus, Trash2, Eye, EyeOff, Edit3, Mail, Users,
  BarChart3, Building2, GraduationCap, Save
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface AdminPanelProps {
  onClose: () => void;
}

const sidebarItems = [
  { id: 'dashboard', label: 'لوحة المعلومات', icon: LayoutDashboard },
  { id: 'videos', label: 'الفيديوهات', icon: Video },
  { id: 'research', label: 'الأبحاث', icon: FileText },
  { id: 'courses', label: 'المقررات', icon: BookOpen },
  { id: 'messages', label: 'الرسائل', icon: MessageSquare },
  { id: 'profile', label: 'الملف الشخصي', icon: Settings },
];

const videoCategories = [
  { value: 'talent-management', label: 'إدارة المواهب' },
  { value: 'performance', label: 'تقييم الأداء' },
  { value: 'training', label: 'التدريب والتطوير' },
  { value: 'leadership', label: 'القيادة والإدارة' },
  { value: 'labor-law', label: 'قوانين العمل' },
  { value: 'career-tips', label: 'نصائح مهنية' },
];

export default function AdminPanel({ onClose }: AdminPanelProps) {
  const [activeSection, setActiveSection] = useState('dashboard');
  const [videos, setVideos] = useState([]);
  const [researches, setResearches] = useState([]);
  const [courses, setCourses] = useState([]);
  const [messages, setMessages] = useState([]);
  const [profile, setProfile] = useState<Record<string, unknown> | null>(null);
  const [showAddVideo, setShowAddVideo] = useState(false);
  const [showAddResearch, setShowAddResearch] = useState(false);
  const [showAddCourse, setShowAddCourse] = useState(false);

  const fetchDashboardData = useCallback(() => {
    fetch('/api/videos?status=published').then(r => r.json()).then(setVideos).catch(() => {});
    fetch('/api/videos?status=draft').then(r => r.json()).then(d => setVideos(prev => [...(Array.isArray(prev) ? prev : []), ...d])).catch(() => {});
    fetch('/api/research?status=published').then(r => r.json()).then(setResearches).catch(() => {});
    fetch('/api/courses').then(r => r.json()).then(setCourses).catch(() => {});
    fetch('/api/messages').then(r => r.json()).then(setMessages).catch(() => {});
    fetch('/api/profile').then(r => r.json()).then(setProfile).catch(() => {});
  }, []);

  useEffect(() => {
    // Fetch all data (including drafts)
    fetch('/api/videos').then(r => r.json()).then(setVideos).catch(() => {});
    fetch('/api/research').then(r => r.json()).then(setResearches).catch(() => {});
    fetch('/api/courses').then(r => r.json()).then(setCourses).catch(() => {});
    fetch('/api/messages').then(r => r.json()).then(setMessages).catch(() => {});
    fetch('/api/profile').then(r => r.json()).then(setProfile).catch(() => {});
  }, []);

  const unreadMessages = messages.filter((m: { isRead: boolean }) => !m.isRead).length;

  const deleteVideo = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا الفيديو؟')) return;
    await fetch(`/api/videos/${id}`, { method: 'DELETE' });
    setVideos(videos.filter((v: { id: string }) => v.id !== id));
  };

  const deleteResearch = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا البحث؟')) return;
    await fetch(`/api/research/${id}`, { method: 'DELETE' });
    setResearches(researches.filter((r: { id: string }) => r.id !== id));
  };

  const deleteCourse = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا المقرر؟')) return;
    await fetch(`/api/courses/${id}`, { method: 'DELETE' });
    setCourses(courses.filter((c: { id: string }) => c.id !== id));
  };

  const markAsRead = async (id: string) => {
    await fetch(`/api/messages/${id}`, { method: 'PUT' });
    setMessages(messages.map((m: { id: string; isRead: boolean }) =>
      m.id === id ? { ...m, isRead: true } : m
    ));
  };

  const deleteMessage = async (id: string) => {
    await fetch(`/api/messages/${id}`, { method: 'DELETE' });
    setMessages(messages.filter((m: { id: string }) => m.id !== id));
  };

  return (
    <div className="fixed inset-0 z-[100] bg-background flex flex-col">
      {/* Header */}
      <div className="bg-primary text-white px-4 py-3 flex items-center justify-between">
        <h1 className="font-bold text-lg">لوحة التحكم</h1>
        <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-primary/80">
          <X className="w-5 h-5" />
        </Button>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <div className="w-56 bg-card border-l border-border overflow-y-auto hidden md:block">
          <div className="p-3 space-y-1">
            {sidebarItems.map(item => (
              <button
                key={item.id}
                onClick={() => setActiveSection(item.id)}
                className={`w-full flex items-center gap-2 px-3 py-2 rounded-md text-sm transition-colors ${
                  activeSection === item.id
                    ? 'bg-primary text-primary-foreground'
                    : 'text-foreground hover:bg-secondary'
                }`}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
                {item.id === 'messages' && unreadMessages > 0 && (
                  <Badge className="mr-auto bg-red-500 text-white text-xs">{unreadMessages}</Badge>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Mobile tabs */}
        <div className="md:hidden flex overflow-x-auto border-b border-border w-full">
          {sidebarItems.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveSection(item.id)}
              className={`flex items-center gap-1 px-3 py-2 text-xs whitespace-nowrap ${
                activeSection === item.id ? 'text-primary border-b-2 border-primary font-semibold' : 'text-muted-foreground'
              }`}
            >
              <item.icon className="w-3 h-3" />
              {item.label}
            </button>
          ))}
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6">
          {activeSection === 'dashboard' && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold text-primary">لوحة المعلومات</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { label: 'الفيديوهات', count: videos.length, icon: Video, color: 'text-blue-600 bg-blue-100' },
                  { label: 'الأبحاث', count: researches.length, icon: FileText, color: 'text-emerald-600 bg-emerald-100' },
                  { label: 'المقررات', count: courses.length, icon: BookOpen, color: 'text-purple-600 bg-purple-100' },
                  { label: 'الرسائل', count: unreadMessages, icon: Mail, color: 'text-amber-600 bg-amber-100' },
                ].map(stat => (
                  <Card key={stat.label}>
                    <CardContent className="p-4">
                      <div className={`w-10 h-10 rounded-lg ${stat.color} flex items-center justify-center mb-2`}>
                        <stat.icon className="w-5 h-5" />
                      </div>
                      <div className="text-2xl font-bold">{stat.count}</div>
                      <div className="text-xs text-muted-foreground">{stat.label}</div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Recent Messages */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">آخر الرسائل</CardTitle>
                </CardHeader>
                <CardContent>
                  {messages.length === 0 ? (
                    <p className="text-muted-foreground text-sm">لا توجد رسائل بعد</p>
                  ) : (
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {messages.slice(0, 5).map((msg: { id: string; name: string; subject: string; isRead: boolean; createdAt: string }) => (
                        <div key={msg.id} className={`flex items-center gap-3 p-2 rounded ${!msg.isRead ? 'bg-primary/5' : ''}`}>
                          <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center shrink-0">
                            <Mail className="w-4 h-4 text-muted-foreground" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="text-sm font-medium truncate">{msg.name}: {msg.subject}</div>
                          </div>
                          {!msg.isRead && <div className="w-2 h-2 rounded-full bg-primary shrink-0" />}
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {activeSection === 'videos' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-primary">الفيديوهات</h2>
                <Button onClick={() => setShowAddVideo(!showAddVideo)} className="gap-1">
                  <Plus className="w-4 h-4" />
                  إضافة فيديو
                </Button>
              </div>

              {showAddVideo && (
                <AddVideoForm onClose={() => setShowAddVideo(false)} onAdded={(v) => { setVideos([v, ...videos]); setShowAddVideo(false); }} />
              )}

              <div className="space-y-3">
                {videos.map((video: { id: string; title: string; category: string; type: string; status: string; featured: boolean; duration: string }) => (
                  <Card key={video.id}>
                    <CardContent className="p-4 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                        <Video className="w-5 h-5 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-sm truncate">{video.title}</div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span>{video.duration}</span>
                          <span>•</span>
                          <span>{video.type === 'short' ? 'قصير' : 'طويل'}</span>
                          {video.featured && <Badge className="text-xs bg-[var(--gold)]/20 text-[var(--gold)]">مميز</Badge>}
                          <Badge variant={video.status === 'published' ? 'default' : 'secondary'} className="text-xs">
                            {video.status === 'published' ? 'منشور' : 'مسودة'}
                          </Badge>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" onClick={() => deleteVideo(video.id)} className="text-red-500 hover:text-red-700">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {activeSection === 'research' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-primary">الأبحاث</h2>
                <Button onClick={() => setShowAddResearch(!showAddResearch)} className="gap-1">
                  <Plus className="w-4 h-4" />
                  إضافة بحث
                </Button>
              </div>

              {showAddResearch && (
                <AddResearchForm onClose={() => setShowAddResearch(false)} onAdded={(r) => { setResearches([r, ...researches]); setShowAddResearch(false); }} />
              )}

              <div className="space-y-3">
                {researches.map((research: { id: string; title: string; category: string; status: string; featured: boolean }) => (
                  <Card key={research.id}>
                    <CardContent className="p-4 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center shrink-0">
                        <FileText className="w-5 h-5 text-emerald-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-sm truncate">{research.title}</div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Badge variant={research.status === 'published' ? 'default' : 'secondary'} className="text-xs">
                            {research.status === 'published' ? 'منشور' : 'مسودة'}
                          </Badge>
                          {research.featured && <Badge className="text-xs bg-[var(--gold)]/20 text-[var(--gold)]">مميز</Badge>}
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" onClick={() => deleteResearch(research.id)} className="text-red-500 hover:text-red-700">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {activeSection === 'courses' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-primary">المقررات</h2>
                <Button onClick={() => setShowAddCourse(!showAddCourse)} className="gap-1">
                  <Plus className="w-4 h-4" />
                  إضافة مقرر
                </Button>
              </div>

              {showAddCourse && (
                <AddCourseForm onClose={() => setShowAddCourse(false)} onAdded={(c) => { setCourses([c, ...courses]); setShowAddCourse(false); }} />
              )}

              <div className="space-y-3">
                {courses.map((course: { id: string; title: string; semester?: string; description: string }) => (
                  <Card key={course.id}>
                    <CardContent className="p-4 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center shrink-0">
                        <BookOpen className="w-5 h-5 text-purple-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-sm truncate">{course.title}</div>
                        {course.semester && <div className="text-xs text-muted-foreground">{course.semester}</div>}
                      </div>
                      <Button variant="ghost" size="icon" onClick={() => deleteCourse(course.id)} className="text-red-500 hover:text-red-700">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {activeSection === 'messages' && (
            <div className="space-y-4">
              <h2 className="text-xl font-bold text-primary">الرسائل</h2>
              {messages.length === 0 ? (
                <Card>
                  <CardContent className="p-8 text-center text-muted-foreground">
                    <Mail className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>لا توجد رسائل بعد</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-3">
                  {messages.map((msg: { id: string; name: string; email: string; subject: string; message: string; isRead: boolean; createdAt: string }) => (
                    <Card key={msg.id} className={!msg.isRead ? 'border-primary/30' : ''}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-semibold text-sm">{msg.name}</span>
                              {!msg.isRead && <div className="w-2 h-2 rounded-full bg-primary" />}
                            </div>
                            <div className="text-xs text-muted-foreground mb-1">{msg.email}</div>
                            <div className="font-medium text-sm text-primary mb-1">{msg.subject}</div>
                            <p className="text-sm text-foreground/80">{msg.message}</p>
                          </div>
                          <div className="flex items-center gap-1 shrink-0">
                            {!msg.isRead && (
                              <Button variant="ghost" size="icon" onClick={() => markAsRead(msg.id)} title="تعليم كمقروء">
                                <Eye className="w-4 h-4" />
                              </Button>
                            )}
                            <Button variant="ghost" size="icon" onClick={() => deleteMessage(msg.id)} className="text-red-500">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeSection === 'profile' && profile && (
            <ProfileEditor profile={profile} onUpdate={setProfile} />
          )}
        </div>
      </div>
    </div>
  );
}

function AddVideoForm({ onClose, onAdded }: { onClose: () => void; onAdded: (v: Record<string, unknown>) => void }) {
  const [form, setForm] = useState({
    title: '', description: '', category: 'talent-management', type: 'long',
    url: '', duration: '', transcript: '', status: 'published', featured: false,
  });
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch('/api/videos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      onAdded(data);
    } catch { /* ignore */ }
    setSaving(false);
  };

  return (
    <Card>
      <CardContent className="p-4">
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-bold text-primary">إضافة فيديو جديد</h3>
            <Button variant="ghost" size="sm" onClick={onClose}><X className="w-4 h-4" /></Button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label className="text-xs">العنوان</Label>
              <Input value={form.title} onChange={e => setForm({...form, title: e.target.value})} required />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">الرابط</Label>
              <Input value={form.url} onChange={e => setForm({...form, url: e.target.value})} required />
            </div>
          </div>
          <div className="space-y-1">
            <Label className="text-xs">الوصف</Label>
            <Textarea value={form.description} onChange={e => setForm({...form, description: e.target.value})} rows={2} required />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-1">
              <Label className="text-xs">التصنيف</Label>
              <Select value={form.category} onValueChange={v => setForm({...form, category: v})}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {videoCategories.map(c => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">النوع</Label>
              <Select value={form.type} onValueChange={v => setForm({...form, type: v})}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="long">طويل</SelectItem>
                  <SelectItem value="short">قصير</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">المدة</Label>
              <Input value={form.duration} onChange={e => setForm({...form, duration: e.target.value})} placeholder="12:35" required />
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Button type="submit" disabled={saving} className="gap-1">
              <Save className="w-4 h-4" />
              {saving ? 'جاري الحفظ...' : 'حفظ'}
            </Button>
            <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}

function AddResearchForm({ onClose, onAdded }: { onClose: () => void; onAdded: (r: Record<string, unknown>) => void }) {
  const [form, setForm] = useState({
    title: '', abstract: '', category: 'training', status: 'published', featured: false,
  });
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch('/api/research', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      onAdded(data);
    } catch { /* ignore */ }
    setSaving(false);
  };

  return (
    <Card>
      <CardContent className="p-4">
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-bold text-primary">إضافة بحث جديد</h3>
            <Button variant="ghost" size="sm" onClick={onClose}><X className="w-4 h-4" /></Button>
          </div>
          <div className="space-y-1">
            <Label className="text-xs">العنوان</Label>
            <Input value={form.title} onChange={e => setForm({...form, title: e.target.value})} required />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">الملخص</Label>
            <Textarea value={form.abstract} onChange={e => setForm({...form, abstract: e.target.value})} rows={3} required />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">التصنيف</Label>
            <Select value={form.category} onValueChange={v => setForm({...form, category: v})}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {videoCategories.map(c => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-4">
            <Button type="submit" disabled={saving} className="gap-1">
              <Save className="w-4 h-4" />
              {saving ? 'جاري الحفظ...' : 'حفظ'}
            </Button>
            <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}

function AddCourseForm({ onClose, onAdded }: { onClose: () => void; onAdded: (c: Record<string, unknown>) => void }) {
  const [form, setForm] = useState({ title: '', description: '', semester: '', status: 'published' });
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch('/api/courses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      onAdded(data);
    } catch { /* ignore */ }
    setSaving(false);
  };

  return (
    <Card>
      <CardContent className="p-4">
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-bold text-primary">إضافة مقرر جديد</h3>
            <Button variant="ghost" size="sm" onClick={onClose}><X className="w-4 h-4" /></Button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label className="text-xs">اسم المقرر</Label>
              <Input value={form.title} onChange={e => setForm({...form, title: e.target.value})} required />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">الفصل الدراسي</Label>
              <Input value={form.semester} onChange={e => setForm({...form, semester: e.target.value})} />
            </div>
          </div>
          <div className="space-y-1">
            <Label className="text-xs">الوصف</Label>
            <Textarea value={form.description} onChange={e => setForm({...form, description: e.target.value})} rows={2} required />
          </div>
          <div className="flex items-center gap-4">
            <Button type="submit" disabled={saving} className="gap-1">
              <Save className="w-4 h-4" />
              {saving ? 'جاري الحفظ...' : 'حفظ'}
            </Button>
            <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}

function ProfileEditor({ profile, onUpdate }: { profile: Record<string, unknown>; onUpdate: (p: Record<string, unknown>) => void }) {
  const [form, setForm] = useState({
    name: (profile.name as string) || '',
    title: (profile.title as string) || '',
    bio: (profile.bio as string) || '',
    email: (profile.email as string) || '',
    phone: (profile.phone as string) || '',
    address: (profile.address as string) || '',
    philosophy: (profile.philosophy as string) || '',
    youtube: (profile.youtube as string) || '',
    facebook: (profile.facebook as string) || '',
    facebookPage: (profile.facebookPage as string) || '',
    linkedin: (profile.linkedin as string) || '',
    researchGate: (profile.researchGate as string) || '',
    googleScholar: (profile.googleScholar as string) || '',
  });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      onUpdate(data);
    } catch { /* ignore */ }
    setSaving(false);
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-primary">الملف الشخصي</h2>
      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label className="text-xs">الاسم</Label>
              <Input value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">المسمى الوظيفي</Label>
              <Input value={form.title} onChange={e => setForm({...form, title: e.target.value})} />
            </div>
          </div>
          <div className="space-y-1">
            <Label className="text-xs">السيرة الذاتية</Label>
            <Textarea value={form.bio} onChange={e => setForm({...form, bio: e.target.value})} rows={3} />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">الفلسفة المهنية</Label>
            <Textarea value={form.philosophy} onChange={e => setForm({...form, philosophy: e.target.value})} rows={2} />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-1">
              <Label className="text-xs">البريد الإلكتروني</Label>
              <Input value={form.email} onChange={e => setForm({...form, email: e.target.value})} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">الهاتف</Label>
              <Input value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">العنوان</Label>
              <Input value={form.address} onChange={e => setForm({...form, address: e.target.value})} />
            </div>
          </div>
          <div className="border-t pt-3 mt-3">
            <h4 className="font-semibold text-sm text-primary mb-3">روابط التواصل الاجتماعي</h4>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs">YouTube</Label>
                <Input value={form.youtube} onChange={e => setForm({...form, youtube: e.target.value})} placeholder="رابط قناة يوتيوب" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">LinkedIn</Label>
                <Input value={form.linkedin} onChange={e => setForm({...form, linkedin: e.target.value})} placeholder="رابط لينكد إن" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Facebook (شخصي)</Label>
                <Input value={form.facebook} onChange={e => setForm({...form, facebook: e.target.value})} placeholder="رابط فيسبوك الشخصي" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Facebook Page (صفحة)</Label>
                <Input value={form.facebookPage} onChange={e => setForm({...form, facebookPage: e.target.value})} placeholder="رابط صفحة فيسبوك" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">ResearchGate</Label>
                <Input value={form.researchGate} onChange={e => setForm({...form, researchGate: e.target.value})} placeholder="رابط ريسيرش جيت" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Google Scholar</Label>
                <Input value={form.googleScholar} onChange={e => setForm({...form, googleScholar: e.target.value})} placeholder="رابط جوجل سكولار" />
              </div>
            </div>
          </div>
          <Button onClick={handleSave} disabled={saving} className="gap-1">
            <Save className="w-4 h-4" />
            {saving ? 'جاري الحفظ...' : 'حفظ التغييرات'}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
