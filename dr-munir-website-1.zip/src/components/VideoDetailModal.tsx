'use client';

import { useState } from 'react';
import { Play, FileText, List, Share2, ExternalLink } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

interface Video {
  id: string;
  title: string;
  description: string;
  category: string;
  type: string;
  url: string;
  thumbnail?: string;
  duration: string;
  transcript?: string;
  keyPoints?: string;
  tags?: string;
  featured: boolean;
  createdAt: string;
}

interface VideoDetailModalProps {
  video: Video | null;
  open: boolean;
  onClose: () => void;
}

const categoryLabels: Record<string, string> = {
  'talent-management': 'إدارة المواهب',
  'performance': 'تقييم الأداء',
  'training': 'التدريب والتطوير',
  'leadership': 'القيادة والإدارة',
  'labor-law': 'قوانين العمل',
  'career-tips': 'نصائح مهنية',
  'hr-kitchen': 'مطبخ الموارد البشرية',
  'job-skills': 'مهارات سوق العمل',
};

export default function VideoDetailModal({ video, open, onClose }: VideoDetailModalProps) {
  const [activeTab, setActiveTab] = useState('watch');

  if (!video) return null;

  const getYouTubeId = (url: string) => {
    const match = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([^&\s]+)/);
    return match ? match[1] : null;
  };

  const youtubeId = getYouTubeId(video.url);
  const keyPoints = video.keyPoints ? JSON.parse(video.keyPoints) : [];
  const tags = video.tags ? JSON.parse(video.tags) : [];

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto rounded-2xl border-0 shadow-2xl">
        <DialogHeader>
          <DialogTitle className="text-right text-lg md:text-xl font-bold text-[#0F2B4C] dark:text-[#E8ECF1]">
            {video.title}
          </DialogTitle>
        </DialogHeader>

        <div className="flex items-center gap-2 mb-4">
          <Badge className="bg-[#0F2B4C]/8 dark:bg-white/10 text-[#0F2B4C] dark:text-[#E8ECF1] border-0 text-xs font-medium">
            {categoryLabels[video.category] || video.category}
          </Badge>
          <span className="text-xs text-muted-foreground">{video.duration}</span>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full mb-4 bg-[#0F2B4C]/5 dark:bg-white/5 rounded-xl p-1">
            <TabsTrigger value="watch" className="flex-1 gap-1 rounded-lg data-[state=active]:bg-white dark:data-[state=active]:bg-[#111B2B] data-[state=active]:shadow-sm">
              <Play className="w-4 h-4" />
              مشاهدة
            </TabsTrigger>
            <TabsTrigger value="transcript" className="flex-1 gap-1 rounded-lg data-[state=active]:bg-white dark:data-[state=active]:bg-[#111B2B] data-[state=active]:shadow-sm">
              <FileText className="w-4 h-4" />
              المحتوى المكتوب
            </TabsTrigger>
          </TabsList>

          <TabsContent value="watch">
            {youtubeId ? (
              <div className="aspect-video rounded-xl overflow-hidden bg-black shadow-lg">
                <iframe
                  src={`https://www.youtube.com/embed/${youtubeId}`}
                  className="w-full h-full"
                  allowFullScreen
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                />
              </div>
            ) : (
              <div className="aspect-video rounded-xl bg-gradient-to-br from-[#0F2B4C] to-[#1A3A5C] flex items-center justify-center shadow-lg">
                <div className="text-center">
                  <a href={video.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 bg-[var(--gold)] text-[#0F2B4C] px-6 py-3 rounded-xl font-bold hover:bg-[#C9960E] transition-colors shadow-md">
                    <ExternalLink className="w-4 h-4" />
                    مشاهدة على يوتيوب
                  </a>
                </div>
              </div>
            )}

            <p className="mt-5 text-foreground/75 text-sm leading-[1.8]">
              {video.description}
            </p>

            {keyPoints.length > 0 && (
              <div className="mt-5 p-5 bg-[#0F2B4C]/3 dark:bg-white/3 rounded-xl">
                <h4 className="font-bold text-[#0F2B4C] dark:text-[#E8ECF1] mb-3 flex items-center gap-2">
                  <List className="w-4 h-4 text-[var(--gold)]" />
                  النقاط الرئيسية
                </h4>
                <ul className="space-y-2">
                  {keyPoints.map((point: string, index: number) => (
                    <li key={index} className="flex items-start gap-3 text-sm text-foreground/75">
                      <span className="w-6 h-6 rounded-lg bg-[var(--gold)]/15 text-[var(--gold)] text-xs flex items-center justify-center shrink-0 mt-0.5 font-bold">
                        {index + 1}
                      </span>
                      {point}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </TabsContent>

          <TabsContent value="transcript">
            {video.transcript ? (
              <div className="bg-[#0F2B4C]/3 dark:bg-white/3 rounded-xl p-6">
                <h4 className="font-bold text-[#0F2B4C] dark:text-[#E8ECF1] mb-4">النسخة المكتوبة</h4>
                <div className="text-foreground/75 text-sm leading-[1.9] whitespace-pre-line">
                  {video.transcript}
                </div>
              </div>
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <FileText className="w-16 h-16 mx-auto mb-4 opacity-20" />
                <p>النسخة المكتوبة غير متوفرة لهذا الفيديو</p>
              </div>
            )}
          </TabsContent>
        </Tabs>

        <div className="flex items-center justify-between mt-5 pt-4 border-t border-[#E0E6EF] dark:border-[#1E2D42]">
          <div className="flex flex-wrap gap-1.5">
            {tags.map((tag: string, index: number) => (
              <Badge key={index} variant="outline" className="text-xs border-[#E0E6EF] dark:border-[#1E2D42] text-muted-foreground">
                {tag}
              </Badge>
            ))}
          </div>
          <Button variant="ghost" size="sm" className="gap-1 text-muted-foreground hover:text-[var(--gold)]">
            <Share2 className="w-4 h-4" />
            مشاركة
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
