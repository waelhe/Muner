'use client';

import { motion } from 'framer-motion';

interface SectionTitleProps {
  title: string;
  subtitle?: string;
  centered?: boolean;
}

export default function SectionTitle({ title, subtitle, centered = true }: SectionTitleProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5 }}
      className={`mb-10 md:mb-14 ${centered ? 'text-center' : ''}`}
    >
      <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-[#0F2B4C] dark:text-[#E8ECF1] mb-3">
        {title}
      </h2>
      {subtitle && (
        <p className="text-muted-foreground text-base md:text-lg max-w-2xl mx-auto leading-relaxed">
          {subtitle}
        </p>
      )}
      {/* Academic decorative divider */}
      <div className={`mt-5 flex items-center gap-2 justify-center ${centered ? '' : 'justify-start'}`}>
        <div className="h-[2px] w-8 bg-[var(--gold)] rounded-full" />
        <div className="w-2 h-2 rounded-full bg-[var(--gold)]" />
        <div className="h-[2px] w-16 bg-gradient-to-r from-[var(--gold)] to-[var(--accent-blue)] rounded-full" />
        <div className="w-2 h-2 rounded-full bg-[var(--accent-blue)]" />
        <div className="h-[2px] w-8 bg-[var(--accent-blue)] rounded-full" />
      </div>
    </motion.div>
  );
}
