import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(_request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const research = await db.research.findUnique({ where: { id } });
    if (!research) return NextResponse.json({ error: 'Research not found' }, { status: 404 });
    return NextResponse.json(research);
  } catch (error) {
    console.error('Error fetching research:', error);
    return NextResponse.json({ error: 'Failed to fetch research' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await request.json();
    const research = await db.research.update({ where: { id }, data: body });
    return NextResponse.json(research);
  } catch (error) {
    console.error('Error updating research:', error);
    return NextResponse.json({ error: 'Failed to update research' }, { status: 500 });
  }
}

export async function DELETE(_request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    await db.research.delete({ where: { id } });
    return NextResponse.json({ message: 'Research deleted' });
  } catch (error) {
    console.error('Error deleting research:', error);
    return NextResponse.json({ error: 'Failed to delete research' }, { status: 500 });
  }
}
