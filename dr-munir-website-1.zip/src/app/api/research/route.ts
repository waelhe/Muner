import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const status = searchParams.get('status') || 'published';

    const where: Record<string, unknown> = { status };
    if (category) where.category = category;

    const research = await db.research.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json(research);
  } catch (error) {
    console.error('Error fetching research:', error);
    return NextResponse.json({ error: 'Failed to fetch research' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const research = await db.research.create({ data: body });
    return NextResponse.json(research, { status: 201 });
  } catch (error) {
    console.error('Error creating research:', error);
    return NextResponse.json({ error: 'Failed to create research' }, { status: 500 });
  }
}
