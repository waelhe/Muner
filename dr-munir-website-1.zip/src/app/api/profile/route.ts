import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function GET() {
  try {
    const profile = await db.profile.findFirst();
    if (!profile) return NextResponse.json(null);
    
    const parsedProfile = {
      ...profile,
      qualifications: profile.qualifications ? JSON.parse(profile.qualifications) : [],
      experience: profile.experience ? JSON.parse(profile.experience) : [],
      researchInterests: profile.researchInterests ? JSON.parse(profile.researchInterests) : [],
      certifications: profile.certifications ? JSON.parse(profile.certifications) : [],
    };
    
    return NextResponse.json(parsedProfile);
  } catch (error) {
    console.error('Error fetching profile:', error);
    return NextResponse.json({ error: 'Failed to fetch profile' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const currentProfile = await db.profile.findFirst();
    
    if (currentProfile) {
      const updateData = { ...body };
      if (typeof updateData.qualifications !== 'string') {
        updateData.qualifications = JSON.stringify(updateData.qualifications);
      }
      if (typeof updateData.experience !== 'string') {
        updateData.experience = JSON.stringify(updateData.experience);
      }
      if (typeof updateData.researchInterests !== 'string') {
        updateData.researchInterests = JSON.stringify(updateData.researchInterests);
      }
      if (typeof updateData.certifications !== 'string') {
        updateData.certifications = JSON.stringify(updateData.certifications);
      }
      
      const profile = await db.profile.update({
        where: { id: currentProfile.id },
        data: updateData,
      });
      return NextResponse.json(profile);
    } else {
      const profile = await db.profile.create({ data: body });
      return NextResponse.json(profile, { status: 201 });
    }
  } catch (error) {
    console.error('Error updating profile:', error);
    return NextResponse.json({ error: 'Failed to update profile' }, { status: 500 });
  }
}
