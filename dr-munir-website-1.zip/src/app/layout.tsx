import type { Metadata } from "next";
import { Cairo } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import ThemeProvider from "@/components/ThemeProvider";

const cairo = Cairo({
  variable: "--font-cairo",
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "600", "700", "800"],
});

export const metadata: Metadata = {
  title: "أستاذ دكتور منير عباس - خبير في إدارة الموارد البشرية",
  description: "الموقع الرسمي لأستاذ دكتور منير عباس، رئيس مجلس أمناء مؤسسة إدارة الموارد البشرية في سورية. خبير في إدارة الموارد البشرية والتطوير التنظيمي بخبرة تزيد عن 25 عاماً. أبحاث، مقررات، فيديوهات، واستشارات.",
  keywords: ["منير عباس", "إدارة الموارد البشرية", "استشارات", "أبحاث", "تدريس", "سوريا", "دمشق", "IHRM", "موارد بشرية", "قيادة", "تطوير تنظيمي", "سلوك تنظيمي"],
  authors: [{ name: "أستاذ دكتور منير عباس" }],
  openGraph: {
    title: "أستاذ دكتور منير عباس - خبير في إدارة الموارد البشرية",
    description: "الموقع الرسمي لأستاذ دكتور منير عباس، رئيس مجلس أمناء مؤسسة إدارة الموارد البشرية في سورية. أبحاث، مقررات، فيديوهات، واستشارات مهنية.",
    type: "website",
    locale: "ar_SY",
    siteName: "أستاذ دكتور منير عباس",
  },
  robots: {
    index: true,
    follow: true,
  },
  icons: {
    icon: "/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body
        className={`${cairo.variable} font-[var(--font-cairo)] antialiased bg-background text-foreground`}
      >
        <ThemeProvider>
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
