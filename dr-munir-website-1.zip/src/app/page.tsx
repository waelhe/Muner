'use client';

import { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import HeroSection from '@/components/HeroSection';
import StatsSection from '@/components/StatsSection';
import AboutSection from '@/components/AboutSection';
import ResearchSection from '@/components/ResearchSection';
import VideosSection from '@/components/VideosSection';
import CoursesSection from '@/components/CoursesSection';
import ConsultationsSection from '@/components/ConsultationsSection';
import ContactSection from '@/components/ContactSection';
import AdminPanel from '@/components/AdminPanel';
import AdminLogin from '@/components/AdminLogin';
import SiteSections from '@/components/SiteSections';
import ScrollToTop from '@/components/ScrollToTop';

export default function Home() {
  const [currentPage, setCurrentPage] = useState('home');
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);

  useEffect(() => {
    fetch('/api/seed', { method: 'POST' })
      .then(res => res.json())
      .then(data => {
        if (data.message === 'Database already seeded') {
          console.log('Database already seeded');
        } else {
          console.log('Database seeded successfully');
        }
      })
      .catch(() => {});
  }, []);

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAdminClick = () => {
    if (isAdminLoggedIn) {
      setShowAdminLogin(false);
    } else {
      setShowAdminLogin(true);
    }
  };

  const handleAdminLogin = (success: boolean) => {
    if (success) {
      setIsAdminLoggedIn(true);
      setShowAdminLogin(false);
    }
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return (
          <>
            <HeroSection onNavigate={handleNavigate} />
            <SiteSections onNavigate={handleNavigate} />
            <StatsSection />
            <LatestVideosPreview onNavigate={handleNavigate} />
          </>
        );
      case 'about':
        return <AboutSection />;
      case 'research':
        return <ResearchSection />;
      case 'videos':
        return <VideosSection />;
      case 'courses':
        return <CoursesSection />;
      case 'consultations':
        return <ConsultationsSection onNavigate={handleNavigate} />;
      case 'contact':
        return <ContactSection />;
      default:
        return (
          <>
            <HeroSection onNavigate={handleNavigate} />
            <SiteSections onNavigate={handleNavigate} />
            <StatsSection />
            <LatestVideosPreview onNavigate={handleNavigate} />
          </>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[var(--background)]">
      <Navbar currentPage={currentPage} onNavigate={handleNavigate} />
      
      <main className="flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            {renderPage()}
          </motion.div>
        </AnimatePresence>
      </main>

      <Footer onNavigate={handleNavigate} onAdminClick={handleAdminClick} />
      <ScrollToTop />

      <AnimatePresence>
        {showAdminLogin && !isAdminLoggedIn && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <AdminLogin
              onLogin={handleAdminLogin}
              onClose={() => setShowAdminLogin(false)}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {isAdminLoggedIn && (
        <AdminPanel onClose={() => setIsAdminLoggedIn(false)} />
      )}
    </div>
  );
}

function getYouTubeThumbnail(url: string): string | null {
  if (!url) return null;
  const match = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([^&\s?]+)/);
  return match ? `https://img.youtube.com/vi/${match[1]}/hqdefault.jpg` : null;
}

function LatestVideosPreview({ onNavigate }: { onNavigate: (page: string) => void }) {
  const [videos, setVideos] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);
  const [imageErrors, setImageErrors] = useState<Set<string>>(new Set());
  const [imageLoaded, setImageLoaded] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetch('/api/videos')
      .then(res => res.json())
      .then(data => {
        setVideos(Array.isArray(data) ? data.slice(0, 3) : []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <section className="py-16 md:py-24 bg-[var(--warm-cream)] dark:bg-[#0A1220]">
        <div className="container mx-auto px-4">
          <div className="text-center mb-10">
            <div className="h-9 bg-secondary rounded-lg w-56 mx-auto animate-pulse" />
            <div className="h-5 bg-secondary rounded-lg w-40 mx-auto mt-3 animate-pulse" />
            <div className="mt-5 flex items-center gap-2 justify-center">
              <div className="h-[2px] w-8 bg-secondary rounded-full animate-pulse" />
              <div className="w-2 h-2 rounded-full bg-secondary animate-pulse" />
              <div className="h-[2px] w-16 bg-secondary rounded-full animate-pulse" />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {[1, 2, 3].map(i => (
              <div key={i} className="bg-white dark:bg-[#111B2B] rounded-xl shadow-md shadow-[#0F2B4C]/5 dark:shadow-black/20 overflow-hidden">
                <div className="aspect-video bg-secondary animate-pulse" />
                <div className="p-4 space-y-3">
                  <div className="h-4 bg-secondary rounded w-20 animate-pulse" />
                  <div className="h-5 bg-secondary rounded w-full animate-pulse" />
                  <div className="h-5 bg-secondary rounded w-3/4 animate-pulse" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (videos.length === 0) return null;

  const categoryLabels: Record<string, string> = {
    'talent-management': 'إدارة المواهب',
    'performance': 'تقييم الأداء',
    'training': 'التدريب والتطوير',
    'leadership': 'القيادة والإدارة',
    'labor-law': 'قوانين العمل',
    'career-tips': 'نصائح مهنية',
    'hr-kitchen': 'مطبخ الموارد البشرية',
    'job-skills': 'مهارات سوق العمل',
  };

  const categoryStyles: Record<string, { bg: string; text: string }> = {
    'talent-management': { bg: 'bg-blue-50', text: 'text-blue-700' },
    'performance': { bg: 'bg-emerald-50', text: 'text-emerald-700' },
    'training': { bg: 'bg-violet-50', text: 'text-violet-700' },
    'leadership': { bg: 'bg-amber-50', text: 'text-amber-700' },
    'labor-law': { bg: 'bg-red-50', text: 'text-red-700' },
    'career-tips': { bg: 'bg-teal-50', text: 'text-teal-700' },
    'hr-kitchen': { bg: 'bg-orange-50', text: 'text-orange-700' },
    'job-skills': { bg: 'bg-cyan-50', text: 'text-cyan-700' },
  };

  return (
    <section className="py-16 md:py-24 bg-[var(--warm-cream)] dark:bg-[#0A1220]">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-10"
        >
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-[#0F2B4C] dark:text-[#E8ECF1] mb-3">
            أحدث الفيديوهات
          </h2>
          <p className="text-muted-foreground text-base md:text-lg">
            شاهد أحدث الفيديوهات التعليمية والإرشادية
          </p>
          <div className="mt-5 flex items-center gap-2 justify-center">
            <div className="h-[2px] w-8 bg-[var(--gold)] rounded-full" />
            <div className="w-2 h-2 rounded-full bg-[var(--gold)]" />
            <div className="h-[2px] w-16 bg-gradient-to-r from-[var(--gold)] to-[var(--accent-blue)] rounded-full" />
            <div className="w-2 h-2 rounded-full bg-[var(--accent-blue)]" />
            <div className="h-[2px] w-8 bg-[var(--accent-blue)] rounded-full" />
          </div>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {videos.map((video, index) => {
            const videoId = video.id as string;
            const thumbnail = getYouTubeThumbnail(video.url as string);
            const hasThumbnail = thumbnail && !imageErrors.has(videoId);
            const catStyle = categoryStyles[video.category as string] || { bg: 'bg-gray-50', text: 'text-gray-700' };

            return (
              <motion.div
                key={videoId}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="bg-white dark:bg-[#111B2B] rounded-xl border-0 shadow-md shadow-[#0F2B4C]/5 dark:shadow-black/20 overflow-hidden cursor-pointer group card-hover-academic"
                onClick={() => onNavigate('videos')}
              >
                <div className="relative aspect-video overflow-hidden">
                  {hasThumbnail ? (
                    <>
                      {!imageLoaded.has(videoId) && (
                        <div className="absolute inset-0 bg-gradient-to-br from-[#0F2B4C] via-[#162D50] to-[#1A3A5C] animate-pulse" />
                      )}
                      <img
                        src={thumbnail!}
                        alt={video.title as string}
                        className={`w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 ${
                          imageLoaded.has(videoId) ? 'opacity-100' : 'opacity-0'
                        }`}
                        onLoad={() => setImageLoaded(prev => new Set(prev).add(videoId))}
                        onError={() => setImageErrors(prev => new Set(prev).add(videoId))}
                        loading="lazy"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
                    </>
                  ) : (
                    <div className="absolute inset-0 bg-gradient-to-br from-[#0F2B4C] via-[#162D50] to-[#1A3A5C]">
                      <div className="absolute inset-0 opacity-10" style={{
                        backgroundImage: `radial-gradient(circle at 30% 40%, rgba(184, 134, 11, 0.3) 0%, transparent 50%)`
                      }} />
                    </div>
                  )}
                  <div className="absolute inset-0 flex items-center justify-center z-10">
                    <div className="w-14 h-14 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center group-hover:bg-white/35 group-hover:scale-110 transition-all duration-300 shadow-lg border border-white/20">
                      <svg className="w-6 h-6 text-white fill-white" viewBox="0 0 24 24">
                        <path d="M8 5v14l11-7z" />
                      </svg>
                    </div>
                  </div>
                  <div className="absolute bottom-2 left-2 flex items-center gap-1 bg-black/70 backdrop-blur-sm text-white text-xs px-2.5 py-1 rounded-lg z-10">
                    <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <circle cx="12" cy="12" r="10" />
                      <polyline points="12 6 12 12 16 14" />
                    </svg>
                    {video.duration as string}
                  </div>
                </div>
                <div className="p-4">
                  <span className={`text-[10px] px-2 py-0.5 rounded-md font-medium ${catStyle.bg} ${catStyle.text} inline-block mb-2`}>
                    {categoryLabels[video.category as string] || (video.category as string)}
                  </span>
                  <h3 className="font-bold text-sm md:text-base text-[#0F2B4C] dark:text-[#E8ECF1] line-clamp-2 group-hover:text-[var(--gold)] transition-colors leading-relaxed">
                    {video.title as string}
                  </h3>
                </div>
              </motion.div>
            );
          })}
        </div>

        <div className="text-center mt-10">
          <button
            onClick={() => onNavigate('videos')}
            className="inline-flex items-center gap-2 text-[#0F2B4C] dark:text-[#E8ECF1] hover:text-[var(--gold)] font-bold text-base transition-colors group"
          >
            عرض جميع الفيديوهات
            <svg className="w-4 h-4 transition-transform group-hover:-translate-x-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="15 18 9 12 15 6" />
            </svg>
          </button>
        </div>
      </div>
    </section>
  );
}
