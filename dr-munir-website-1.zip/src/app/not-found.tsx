'use client';

import { motion } from 'framer-motion';
import { Home, ArrowLeft, Search, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useRouter } from 'next/navigation';

export default function NotFound() {
  const router = useRouter();

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden bg-[var(--background)]">
      {/* Background decorations */}
      <div className="absolute inset-0 bg-gradient-to-bl from-[#0F2B4C]/5 via-transparent to-[var(--gold)]/5" />
      <div className="absolute top-0 left-0 w-96 h-96 bg-[var(--gold)]/5 rounded-full blur-[120px] -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-[var(--accent-blue)]/5 rounded-full blur-[120px] translate-x-1/3 translate-y-1/3" />

      {/* Geometric pattern */}
      <div className="absolute inset-0 opacity-[0.02]" style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%230F2B4C' fill-opacity='1'%3E%3Cpath d='M36 34v6h-6v-6h6zm0-30v6h-6V4h6zm0 10v6h-6v-6h6zm0 10v6h-6v-6h6zm-10 0v6h-6v-6h6zm-10 0v6h-6v-6h6zm30 0v6h-6v-6h6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
      }} />

      <div className="relative z-10 text-center px-4 max-w-lg">
        {/* 404 Number */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="mb-6"
        >
          <div className="relative inline-block">
            <span className="text-[120px] md:text-[160px] font-bold leading-none bg-gradient-to-br from-[#0F2B4C] via-[var(--accent-blue)] to-[var(--gold)] bg-clip-text text-transparent">
              404
            </span>
            <div className="absolute -inset-4 bg-gradient-to-r from-[#0F2B4C]/5 to-[var(--gold)]/5 blur-3xl rounded-full -z-10" />
          </div>
        </motion.div>

        {/* Icon */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mb-6"
        >
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-[#0F2B4C]/10 border border-[#0F2B4C]/10">
            <BookOpen className="w-10 h-10 text-[#0F2B4C]/60" />
          </div>
        </motion.div>

        {/* Title */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="text-2xl md:text-3xl font-bold text-[#0F2B4C] mb-3"
        >
          الصفحة غير موجودة
        </motion.h1>

        {/* Description */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="text-muted-foreground text-base md:text-lg leading-relaxed mb-8"
        >
          عذراً، الصفحة التي تبحث عنها غير موجودة أو تم نقلها إلى عنوان آخر. يمكنك العودة للصفحة الرئيسية أو البحث عن المحتوى المطلوب.
        </motion.p>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-3"
        >
          <Button
            onClick={() => router.push('/')}
            size="lg"
            className="btn-academic bg-[#0F2B4C] hover:bg-[#162D50] text-white font-bold gap-2 rounded-xl px-8 h-12 text-base shadow-lg shadow-[#0F2B4C]/20"
          >
            <Home className="w-4 h-4" />
            الصفحة الرئيسية
          </Button>
          <Button
            onClick={() => router.back()}
            variant="outline"
            size="lg"
            className="gap-2 rounded-xl px-8 h-12 text-base border-[#0F2B4C]/20 text-[#0F2B4C] hover:bg-[#0F2B4C]/5"
          >
            <ArrowLeft className="w-4 h-4" />
            رجوع
          </Button>
        </motion.div>

        {/* Decorative dots */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="mt-12 flex items-center justify-center gap-2"
        >
          <div className="w-2 h-2 rounded-full bg-[var(--gold)]/30" />
          <div className="h-[2px] w-8 bg-[var(--gold)]/20 rounded-full" />
          <div className="w-2 h-2 rounded-full bg-[var(--accent-blue)]/30" />
          <div className="h-[2px] w-8 bg-[var(--accent-blue)]/20 rounded-full" />
          <div className="w-2 h-2 rounded-full bg-[#0F2B4C]/20" />
        </motion.div>
      </div>
    </div>
  );
}
