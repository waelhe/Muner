import { cookies } from 'next/headers';

const JWT_SECRET = 'dr-munir-abbas-website-secret-key-2024';
const TOKEN_NAME = 'admin_token';

export function hashPassword(password: string): string {
  // Simple hash for demo - in production use bcrypt
  let hash = 0;
  const str = password + JWT_SECRET;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(36);
}

export function verifyPassword(password: string, hashedPassword: string): boolean {
  return hashPassword(password) === hashedPassword;
}

export function createToken(adminId: string, email: string): string {
  // Simple token encoding for demo - in production use proper JWT
  const payload = JSON.stringify({ id: adminId, email, exp: Date.now() + 86400000 });
  return Buffer.from(payload).toString('base64');
}

export function verifyToken(token: string): { id: string; email: string } | null {
  try {
    const payload = JSON.parse(Buffer.from(token, 'base64').toString());
    if (payload.exp && payload.exp > Date.now()) {
      return { id: payload.id, email: payload.email };
    }
    return null;
  } catch {
    return null;
  }
}

export async function getAdminFromCookie(): Promise<{ id: string; email: string } | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(TOKEN_NAME)?.value;
  if (!token) return null;
  return verifyToken(token);
}

export { TOKEN_NAME };
